#include <bits/stdc++.h>
#define PI 			acos(-1)
#define mp			make_pair
#define pb			push_back
#define all(a)		(a).begin(), (a).end()
#define srt(a)			sort(all(a))
#define mem(a, h)	memset(a, (h), sizeof(a))
#define f 			first
#define s 			second
#define MOD			1000000007
#define EPS			1e-9
int in(){int r=0,c;for(c=getchar();c<=32;c=getchar());if(c=='-') return -in();for(;c>32;r=(r<<1)+(r<<3)+c-'0',c=getchar());return r;}

using namespace std;

typedef long long 		ll;
typedef unsigned long long 		ull;
typedef pair<int, int>  ii;
typedef vector<int>     vi;
typedef vector<ii>      vii;
typedef vector<ll>      vll;
vi g[100005];
int n,m;
bool cat[100005], visited[100005];
int dfs(int node, int cats)
{
	if(cat[node])
		cats++;
	else
		cats = 0;
	if(cats > m) return 0;
	if(node != 0 && g[node].size() == 1)
		return 1;
	visited[node] = 1;
	int r = 0;
	for(int i = 0; i < g[node].size(); i++)
	{
		if(!visited[g[node][i]])
			r += dfs(g[node][i],cats);
	}
	//cout<<node<<' '<<cats<<endl;
	return r;
}
int main()
{
	ios::sync_with_stdio(false); cin.tie(0);
	//freopen("qwe.txt", "r", stdin);
	//freopen("asd.txt", "w", stdout);
	mem(cat,0);
	mem(visited,0);
	cin>>n>>m;
	for(int i = 0; i<n; i++)
		cin>>cat[i];
	int a,b;
	for(int i = 0; i< n-1; i++)
	{
		cin>>a>>b;
		g[a-1].pb(b-1);
		g[b-1].pb(a-1);
	}
	cout<<dfs(0,0);
	return 0;
}

// read the question correctly (is y a vowel? what are the exact constraints?)
// look out for SPECIAL CASES (n=1?) and overflow (ll vs int?) ARRAY OUT OF BOUNDSS