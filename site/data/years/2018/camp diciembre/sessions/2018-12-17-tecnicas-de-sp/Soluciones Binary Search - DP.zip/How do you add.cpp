#include <bits/stdc++.h>
#define PI                acos(-1)
#define pb                push_back
#define mp                make_pair
#define all(a)            (a).begin(), (a).end()
#define clr(a,h)          memset(a, (h), sizeof(a))
#define F first
#define S second
int faster_in(){int r=0,c;for(c=getchar();c<=32;c=getchar());if(c=='-') return -faster_in();for(;c>32;r=(r<<1)+(r<<3)+c-'0',c=getchar());return r;}

using namespace std;

typedef long long       ll;
typedef pair<int, int>  ii;
typedef vector<int>     vi;
typedef vector<ii>      vii;
typedef vector<ll>      vll;
const int INF = int(1e9 + 7);

ll dp[110][110], N, K;

ll MOD = 1000000;

ll f(ll n, ll k)
{
	if (k == 1) return 1;
	if (n < 0) return 0;
	if (k < 0) return 0;
	
	if (dp[n][k] != -1) return dp[n][k];

	ll res = 0;
	for (ll x = 0; x <= n; x++)
	{	
		res += f(n-x, k-1);
		res %= MOD;
	}
	dp[n][k] = res;
	return res;
}

int main()
{
    std::ios::sync_with_stdio(false); cin.tie(0);
    //freopen("","r",stdin);
    //freopen("out.txt","w",stdout);
    while (cin >> N >> K)
    {
    	if (N == 0 && K == 0) break;
    	clr(dp, -1);
    	cout << f(N, K) << '\n';
    }
    return 0;
}
// PLUS ULTRA!