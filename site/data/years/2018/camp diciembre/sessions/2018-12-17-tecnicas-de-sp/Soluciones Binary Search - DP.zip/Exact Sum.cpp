#include <bits/stdc++.h>
#define PI                acos(-1)
#define pb                push_back
#define mp                make_pair
#define all(a)            (a).begin(), (a).end()
#define clr(a,h)          memset(a, (h), sizeof(a))
#define F first
#define S second
int faster_in(){int r=0,c;for(c=getchar();c<=32;c=getchar());if(c=='-') return -faster_in();for(;c>32;r=(r<<1)+(r<<3)+c-'0',c=getchar());return r;}

using namespace std;

typedef long long       ll;
typedef pair<int, int>  ii;
typedef vector<int>     vi;
typedef vector<ii>      vii;
typedef vector<ll>      vll;
const int INF = int(1e9 + 7);

const int tam = 10010;

int a[tam], n;

// Esta funcion nos dice si x esta en el arreglo ordenado
// usando busqueda binaria
// Si queremos encontrar x, buscamos el primer numero >= x
// si ese numero es diferente de x, entonces x no existe en nuestro arreglo
bool findNumber(int x)
{
	int lo = 0, hi = n-1, mid, res = -1;
	while (lo <= hi)
	{
		mid = (lo + hi) / 2;
		if ( a[mid] >= x ) 
		{
			res = mid;
			hi = mid - 1;
		}
		else
		{
			lo = mid + 1;
		}
	}
	if (res == -1 || a[res] != x) return false;
	else return true;
}

int main()
{
    std::ios::sync_with_stdio(false); cin.tie(0);
    //freopen("","r",stdin);
    //freopen("","w",stdout);
    while (cin >> n)
    {
    	for (int i = 0; i < n; i++)
    	{
    		cin >> a[i];
    	}
    	int x;
    	cin >> x;

    	
		//	Caso especial: x es par y hay dos libros con precio x/2
    	int mitad = 0;
    	for (int i = 0; i < n; i++)
    	{
    		if (x%2 == 0 && a[i] == x/2) mitad++;
    	}
    	if (mitad >= 2)
    	{
    		cout << "Peter should buy books whose prices are " << x/2 << " and " << x/2 << '.' << '\n';
    		continue;
    	}
    	
    	sort( a, a + n );
    	int A = -1, B;
    	for (int i = 0; i < n; i++)
    	{
    		if ( x - a[i] < a[i] ) break; // Nos especifican que en el output el menor siempre ira primero

    		// Si el libro cuesta a[i], necesitamos saber si hay un libro con precio x - a[i]
    		if ( findNumber( x - a[i] ) == true )
    		{
    			A = a[i];
    			B = x - a[i];
    		}
    	}

    	cout << "Peter should buy books whose prices are " << A << " and " << B << '.' << '\n';
    	cout << '\n';
    }
    return 0;
}
// PLUS ULTRA!