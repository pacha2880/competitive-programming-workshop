#include <bits/stdc++.h>
#define PI                acos(-1)
#define pb                push_back
#define mp                make_pair
#define all(a)            (a).begin(), (a).end()
#define clr(a,h)          memset(a, (h), sizeof(a))
#define F first
#define S second
int faster_in(){int r=0,c;for(c=getchar();c<=32;c=getchar());if(c=='-') return -faster_in();for(;c>32;r=(r<<1)+(r<<3)+c-'0',c=getchar());return r;}

using namespace std;

typedef long long       ll;
typedef pair<int, int>  ii;
typedef vector<int>     vi;
typedef vector<ii>      vii;
typedef vector<ll>      vll;
const int INF = int(1e9 + 7);

const int tam = 10010;

int dp[tam], n, m, t;

int main()
{
    std::ios::sync_with_stdio(false); cin.tie(0);
    //freopen("","r",stdin);
    //freopen("","w",stdout);
    while (cin >> n >> m >> t)
    {
    	clr(dp, 0);
    	for (int i = 0; i <= t; i++)
    	{
    		if (i == 0 || dp[i] > 0)
    		{
    			if (i+n <= t) dp[i+n] = max(dp[i+n], dp[i]+1);
    			if (i+m <= t) dp[i+m] = max(dp[i+m], dp[i]+1);
    		}
    	}
    	int res = 0;
    	for (int i = t; i >= 0; i--)
    	{
    		if (dp[i] > 0)
    		{
    			res = i;
    			break;
    		}
    	}
    	if (res == t) cout << dp[res] << '\n';
    	else cout << dp[res] << ' ' << t-res << '\n';
    }
    return 0;
}
// PLUS ULTRA!