#include <bits/stdc++.h>
typedef long long       ll;
#define PI                acos(-1)
#define pb                push_back
#define mp                make_pair
#define mt                make_tuple
#define all(a)            (a).begin(), (a).end()
#define clr(a,h)          memset(a, (h), sizeof(a))
#define F first
#define S second
#define fore(i,b,e)      for(int i=(int)b,o_o=e;i<(int)o_o;++i)
#define forr(i,b,e)      for(int i=(int)b,o_o=e;i<(int)o_o;++i)
#define deb(x)        cerr << "# " << (#x) << " = " << (x) << endl;
#define sz(x)             (int)x.size()
int faster_in(){int r=0,c;for(c=getchar();c<=32;c=getchar());if(c=='-') return -faster_in();for(;c>32;r=(r<<1)+(r<<3)+c-'0',c=getchar());return r;}
 
using namespace std;
 
typedef pair<int, int>  ii;
typedef vector<int>     vi;
typedef vector<ii>      vii;
typedef vector<ll>      vll;
const int INF = 1234567890;
 
const int tam = 20;
 
ii dp[(1<<tam)]; // rides, peso
int n, x, w[tam];
 
ii f(int mask) {
  if (mask == 0) return {1, 0};
  ii &res = dp[mask];
  if (res.first != -1) return res;
  res = {INF, INF};
  fore(i, 0, n) {
    if ((mask & (1<<i))) {
      ii r = f(mask^(1<<i));
      if (r.second + w[i] <= x) {
        r.second += w[i];
        res = min(res, r);
      }
      else {
        r.first++;
        r.second = w[i];
        res = min(res, r);
      }
    }
  }
  return res;
} 
 
int main()
{
  std::ios::sync_with_stdio(false); cin.tie(0);
  //freopen("","r",stdin);
  //freopen("","w",stdout);
  fore(i, 0, (1<<tam)) dp[i] = {-1,-1};
  cin >> n >> x;
  fore(i, 0, n) cin >> w[i];
  cout << f((1<<n)-1).first << '\n';
  return 0;
}
// Dinosaurs are cool!