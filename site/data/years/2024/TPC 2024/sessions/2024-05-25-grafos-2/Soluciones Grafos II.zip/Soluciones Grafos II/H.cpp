#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> ii;
typedef long double ld;
#define pb push_back
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define all(x) x.begin(), x.end()
#define dbg(x) cerr << #x << ": " << x  << endl;
#define raya cerr << "=================================" << endl;
 
struct unionFind {
    vector<int> p;              
    vector<int> tam;
    int mxTam;

    unionFind(int n) : p(n, -1), tam(n, 1), mxTam(1) {}
    int find(int x){
        if(p[x] == -1) return x;
        return p[x] = find(p[x]);
    }
    bool join(int x, int y){
        x = find(x), y = find(y);          
        if(x == y) return 0;
        p[y] = x;        
        tam[x] += tam[y];
        mxTam = max(mxTam, tam[x]);
        return 1;
    }
};
 
int main(){
    int n, m;
	cin >> n >> m;

    unionFind dsu(n+1);

	int c = n;
	while(m--){
		int a, b;
		cin >> a >> b;
        if(dsu.join(a, b)){
			c--;
		}
		cout << c << ' ' << dsu.mxTam << '\n';
	}
 
}