
#include<bits/stdc++.h>
using namespace std;
 
#define ld long double
#define lcm(a,b) a*b/__gcd(a,b)
#define pb push_back
#define ii pair<int,int>
#define vi vector<int>
#define vii vector<pair<int,int>>
#define fst first
#define snd second
#define sz(x) (int)x.size()
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define raya cerr << "==========================" << endl;
#define fore(a, b, c) for(int a=b; a<c; ++a)
#define all(x) x.begin(), x.end()
#define endl '\n';
 
void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}
template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
#define dbg(x...) cerr << "[" << #x << "] = ["; _print(x)
 
const double EPS = 1e-7;
const double PI = acos(-1);
const int MOD = 1e9+7;  
int TC = 1;
 
const int N = 1e5+5;
const int M = 2e5+5;
 
using ll = long long;
const ll INF = 4e18;

vector<ll> p(N, -1);
 
vector<ll> dijkstra(vector<vector<pair<ll,ll>>> G, int n, int s){
    // G -> Vector de vector de pares, guarda el grafo con pesos.
    // n -> Cantidad de nodos.
    // s -> Nodo inicial
    vector<ll> dis(n+1, INF);  
    dis[s] = 0;   
    
    priority_queue<pair<ll,ll>, vector<pair<ll,ll>>, greater<pair<ll,ll>>> pq;  // Cola de prioridad que nos da los menores primero.
    pq.push({0, s});    
    while(!pq.empty()){     
        pair<ll,ll> menor = pq.top();   
        pq.pop();                       
        int w = menor.first;            
        int nodo = menor.second;        
        if(dis[nodo] < w) continue;     
        for(auto to : G[nodo]){         
            int v = to.first;           
            int cost = to.second;       
            if(dis[nodo] + cost < dis[v]){     
                dis[v] = dis[nodo] + cost;     
                p[v] = nodo;  // Ahora 'nodo' es el nodo del que llegé a 'v'
                pq.push({dis[v], v});          
            }
        }
    }
    return dis;     
}
 
void solve(){
    ll n, m;
	cin >> n >> m;
    vector<vector<pair<ll,ll>>> adj(n+1);
    fore(i, 0, m){
        ll u, v, w;
        cin >> u >> v >> w;
        adj[u].pb({v, w});
        adj[v].pb({u, w});  // el grafo es bidireccional
    }
 
    vector<ll> dis = dijkstra(adj, n, 1);
 
    if(dis[n] == 4e18){
        cout << -1 << endl;
        return;
    }

    int cur = n;
    vi ans;
    while(cur != -1){
        ans.push_back(cur);
        cur = p[cur];
    }

    reverse(all(ans));
    for(int x : ans){
        cout << x << ' ';
    }

}
 
signed main(){
    fast;
    // cin >> TC;
    while(TC--){
        solve();
    }
}
