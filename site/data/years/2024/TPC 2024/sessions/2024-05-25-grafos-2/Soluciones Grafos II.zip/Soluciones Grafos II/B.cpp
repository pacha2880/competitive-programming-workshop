#include<bits/stdc++.h>
using namespace std;
 
#define ll long long
#define ld long double
#define lcm(a,b) a*b/__gcd(a,b)
#define pb push_back
#define ii pair<int,int>
#define vi vector<int>
#define vii vector<pair<int,int>>
#define fst first
#define snd second
#define sz(x) (int)x.size()
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define raya cerr << "==========================" << endl;
#define fore(a, b, c) for(int a=b; a<c; ++a)
#define all(x) x.begin(), x.end()
#define endl '\n';
 
void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}
template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
#define dbg(x...) cerr << "[" << #x << "] = ["; _print(x)
 
const double EPS = 1e-7;
const double PI = acos(-1);
const int MOD = 1e9+7;  
int TC = 1;
 
 
struct unionFind {
    vector<int> p;              
    unionFind(int n) : p(n, -1) {}
    int find(int x){
        if(p[x] == -1) return x;
        return p[x] = find(p[x]);
    }
    bool join(int x, int y){
        x = find(x), y = find(y);          
        if(x == y) return 0;
        p[y] = x;        
        return 1;
    }
};
 
ll kruskal(vector<pair<ll,pair<int,int>>> edges, int n){
 
    // edges -> guarda las aristas en al forma {peso, {u, v}}
 
    sort(edges.begin(), edges.end());       // Ordenamos las aristas de peso menor a mayor.
    unionFind dsu(n+1);
    int cntAristas = 0;     // Cuantas aristas ya hemos añadido
    ll res = 0;        // Peso total del árbol de expansión mínima.
    for(auto e : edges){
        ll peso = e.first;     // Peso de la arista actual
        int u = e.second.first;
        int v = e.second.second;
        if(dsu.join(u, v)){     
            cntAristas++;       
            res += peso;
        }
        if(cntAristas == n-1){      // Terminamos porque solo se necesitan n - 1 aristas para cualquier árbol de n nodos.
            return res;
        }
    }
    if(cntAristas < n - 1){
        return -1;
    }
    return res;
}
 
void solve(){
    int n, m;
	cin >> n >> m;
 
    vector<pair<ll,pair<int,int>>> edges;
    fore(i, 0, m){
        ll u, v, c;
        cin >> u >> v >> c;
        edges.push_back({c, {u, v}});
    }
    ll res = kruskal(edges, n);
    if(res == -1){
        cout << "IMPOSSIBLE" << endl;
    } else {
        cout << res << endl;
    }
}
 
int main(){
    fast;
    // cin >> TC;
    while(TC--){
        solve();
    }
}