#include<bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
uniform_int_distribution<int> dist(1, 10);
#define ll long long
#define ld long double
#define gcd(a, b) __gcd(a, b)
#define lcm(a,b) a*b/gcd(a,b)
#define pb push_back
#define ii pair<int,int>
#define vi vector<int>
#define vii vector<pair<int,int>>
#define F first
#define S second
#define sz(x) (int)x.size()
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define fore(a, b, c) for(int a=b; a<c; ++a)
#define all(x) x.begin(), x.end()
#define int ll
#define endl '\n';
template <typename T>
using ordered_set = tree<T, null_type,less<T>, rb_tree_tag,tree_order_statistics_node_update>;
void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}
template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
#define dbg(x...) cerr << "[" << #x << "] = ["; _print(x)
#define raya cerr << "==========================" << endl;
const double EPS = 1e-7;
const double PI = acos(-1);
const int MOD = 1e9+7;  
int TC = 0;

struct unionFind {
    vi p;
    unionFind(int n) : p(n+1, -1) {}
    int find(int a){
        if(p[a] == -1) return a;
        return p[a] = find(p[a]);
    }
    bool join(int a, int b){
        a = find(a), b = find(b);
        if(a == b){
            return 0;
        }
        p[b] = a;
        return 1;
    }
};

struct edge {
    int k, c;
    vi arr; // la lista de nodos
    bool operator<(edge &otro) const {
        return tie(c, k) < tie(otro.c, otro.k);
    }
};

// vector<pair<int,vector<int>>> edges;  //  {c, arr}

void solve(){
    int n, m;
    cin >> n >> m;

    unionFind dsu(n);

    int ans = 0;
    int cntJoins = 0;

    vector<edge> edges;

    fore(i, 0, m){
        int k, c;
        cin >> k >> c;

        vi tmp;

        fore(i, 0, k){
            int x;
            cin >> x;
            tmp.pb(x);
        }

        edges.push_back({k, c, tmp});

    }

    // Lo siguiente es basicamente Kruskal

    sort(all(edges));

    fore(i, 0, m){
        int k = edges[i].k;
        int c = edges[i].c;

        vi &arr = edges[i].arr;

        int tmpNode = -1;

        fore(j, 0, k){
            int node = arr[j];
            if(j == 0){
                tmpNode = node;
            }

            if(dsu.join(tmpNode, node)){
                ans += c;
                cntJoins++;
            }

        }
    }

    if(cntJoins < n - 1){
        cout << -1 << endl;
        return;
    }

    cout << ans << endl;

}
    
signed main(){
    fast;
    int tt = 1;
    // cin >> tt;
    while(tt--){
        TC++;
        solve();
    }
}
