#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define ld long double
#define gcd(a, b) __gcd(a, b)
#define lcm(a,b) a*b/gcd(a,b)
#define pb push_back
#define ii pair<int,int>
#define vi vector<int>
#define vii vector<pair<int,int>>
#define F first
#define S second
#define sz(x) (int)x.size()
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define fore(a, b, c) for(int a=b; a<c; ++a)
#define all(x) x.begin(), x.end()
#define endl '\n';

void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}
template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
#define dbg(x...) cerr << "[" << #x << "] = ["; _print(x)
#define raya cerr << "==========================" << endl;

const double EPS = 1e-7;
const double PI = acos(-1);
const int MOD = 1e9+7;  
int TC = 1;

bitset<10> aux;
const int inf = 1e9+5;

void solve(){
    int n, m;
    cin >> n >> m;
    cin >> aux;
    int s = aux.to_ulong();
    vector<array<int,3>> edges(m);  // [sana, side, cost]
    fore(i, 0, m){
        cin >> edges[i][2];
        cin >> aux;
        edges[i][0] = ((1 << n) - 1) ^ aux.to_ulong();  // sana
        cin >> aux;
        edges[i][1] = aux.to_ulong();   // side
    }

    vector<int> dist(1<<n, inf);
    dist[s] = 0;
    priority_queue<ii, vii, greater<ii>> pq;
    pq.push({0, s});
    while(sz(pq)){
        auto cur = pq.top();
        pq.pop();
        int nodo = cur.second;
        int cost = cur.first;
        if(dist[nodo] != cost) continue;
        fore(i, 0, m){
            int to = nodo & edges[i][0];
            to |= edges[i][1];
            int dias = edges[i][2];
            if(dist[to] > cost + dias){
                dist[to] = cost + dias;
                pq.push({dist[to], to});
            }
        }
    }
    if(dist[0] == inf) dist[0] = -1;
    cout << dist[0] << endl;
}

int main(){
    fast;
    cin >> TC;
    while(TC--){
        solve();
    }
}