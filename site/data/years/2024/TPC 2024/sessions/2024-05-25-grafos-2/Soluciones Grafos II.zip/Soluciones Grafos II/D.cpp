#include<bits/stdc++.h>
using namespace std;
 
#define ld long double
#define gcd(a, b) __gcd(a, b)
#define lcm(a,b) a*b/gcd(a,b)
#define pb push_back
#define ii pair<int,int>
#define vi vector<int>
#define vii vector<pair<int,int>>
#define fst first
#define snd second
#define sz(x) (int)x.size()
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define fore(a, b, c) for(int a=b; a<c; ++a)
#define all(x) x.begin(), x.end()
#define endl '\n';
 
void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}
template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
#define dbg(x...) cerr << "[" << #x << "] = ["; _print(x)
#define raya cerr << "==========================" << endl;
 
const double EPS = 1e-7;
const double PI = acos(-1);
const int MOD = 1e9+7;  
int TC = 1;
 
using ll = long long;
const ll INF = 4e18;
 
vector<vector<ll>> floydWarshall(vector<vector<pair<ll,ll>>> G, int n){
    vector<vector<ll>> dis(n+1, vector<ll>(n+1, INF));
    for(int i=1; i<=n; ++i){    
        dis[i][i] = 0;
    }
    for(int u=1; u<=n; ++u){    // Revisamos todas las aristas del grafo.
        for(auto to : G[u]){
            ll v = to.first, w = to.second;
            dis[u][v] = min(dis[u][v], w);     
            dis[v][u] = min(dis[v][u], w);  // Si el grafo es no dirigido
        }
    }
    for(int k=1; k<=n; ++k){        // Intermediario
        for(int u=1; u<=n; ++u){       // Nodo u
            for(int v=1; v<=n; ++v){    // Nodo v
                dis[u][v] = min(dis[u][v], dis[u][k] + dis[k][v]);
            }
        }
    }
    return dis;
}
 
void solve(){
    int n, m, q;
    cin >> n >> m >> q;
    vector<vector<pair<ll,ll>>> adj(n+1);
    fore(i, 0, m){
        int u, v, c;
        cin >> u >> v >> c;
        adj[u].pb({v, c});
    }
    vector<vector<ll>> dis = floydWarshall(adj, n);
    while(q--){
        int u, v;
        cin >> u >> v;
        cout << (dis[u][v] == 4e18 ? -1 : dis[u][v]) << endl;
        // if(dis[u][v] == 4e18){
        //     cout << -1 << endl;
        // } else {
        //     cout << dis[u][v] << endl;
        // }
    }
}       
 
signed main(){
    fast;
    // cin >> TC;
    int TC = 1;
    while(TC--){
        solve();
    }
}