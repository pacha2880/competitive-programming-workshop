#include<bits/stdc++.h>
using namespace std;
 
#define ld long double
#define lcm(a,b) a*b/__gcd(a,b)
#define pb push_back
#define ii pair<int,int>
#define vi vector<int>
#define vii vector<pair<int,int>>
#define fst first
#define snd second
#define sz(x) (int)x.size()
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define raya cerr << "==========================" << endl;
#define fore(a, b, c) for(int a=b; a<c; ++a)
#define all(x) x.begin(), x.end()
#define endl '\n';
 
void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}
template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
#define dbg(x...) cerr << "[" << #x << "] = ["; _print(x)
 
const double EPS = 1e-7;
const double PI = acos(-1);
const int MOD = 1e9+7;  
int TC = 1;
 
const int N = 1e5+5;
const int M = 2e5+5;
 
using ll = long long;
const ll INF = 4e18;
 
vector<ll> dijkstra(vector<vector<pair<ll,ll>>> G, int n, int s){
    // G -> Vector de vector de pares, guarda el grafo con pesos.
    // n -> Cantidad de nodos.
    // s -> Nodo inicial
    vector<ll> dis(n+1, INF);  
    dis[s] = 0;   
    // Vamos a guardar pares {w, nodo} donde w es el costo con el que llegamos al nodo.
    // Es importante que primero este el costo w, ya que de ese modo se ordenara de acuerdo a los pesos.
    priority_queue<pair<ll,ll>, vector<pair<ll,ll>>, greater<pair<ll,ll>>> pq;  // Cola de prioridad que nos da los menores primero.
    pq.push({0, s});    // El primer nodo pendiente es s, con peso 0.
    while(!pq.empty()){     // Mientras existan nodos pendientes.
        pair<ll,ll> menor = pq.top();     // Recuperamos el nodo con menor distancia.
        pq.pop();                       // Lo quitamos de pendientes.
        int w = menor.first;            // Costo del nodo actual
        int nodo = menor.second;        // Nodo actual
        if(dis[nodo] < w) continue;     // Anteriormente encontramos una distancia menor a la del costo actual, asi que ahora no hacemos nada
        for(auto to : G[nodo]){         
            int v = to.first;           // Nodo vecino 
            int cost = to.second;       // Costo para ir al nodo v
            if(dis[nodo] + cost < dis[v]){      // Se puede mejorar la distancia minima al nodo v
                dis[v] = dis[nodo] + cost;      // Actualizamos la distancia mejorada
                pq.push({dis[v], v});           // Hicimos una mejora, asi que lo insertamos en pendientes al nodo mejorado
            }
        }
    }
    return dis;     
}
 
void solve(){
    ll n, m;
	cin >> n >> m;
    vector<vector<pair<ll,ll>>> adj(n+1);
    fore(i, 0, m){
        ll u, v, w;
        cin >> u >> v >> w;
        adj[u].pb({v, w});
    }
 
    vector<ll> dis = dijkstra(adj, n, 1);
 
    fore(i, 1, n+1){
        cout << dis[i] << ' ';
    }
}
 
signed main(){
    fast;
    // cin >> TC;
    while(TC--){
        solve();
    }
}
