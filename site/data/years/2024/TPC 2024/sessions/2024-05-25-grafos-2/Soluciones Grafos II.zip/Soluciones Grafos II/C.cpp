#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> ii;
typedef long double ld;
#define lcm(a,b) a*b/__gcd(a,b)
#define INF 1000000000
#define pb push_back
#define fst first
#define snd second
#define fast ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define fore(a, b, c) for(int a=b; a<c; ++a)
#define all(x) x.begin(), x.end()
#define dbg(x) cerr << #x << ": " << x  << endl;
#define raya cerr << "=================================" << endl;
const double PI = 3.141592653589793;
const int MOD = 1e9+7;

const int N = 1e4+5;
int n;
int p[N];

struct unionFind {
    vector<int> p;              
    unionFind(int n) : p(n, -1) {}
    int find(int x){
        if(p[x] == -1) return x;
        return p[x] = find(p[x]);
    }
    bool join(int x, int y){
        x = find(x), y = find(y);          
        if(x == y) return 0;
        p[y] = x;        
        return 1;
    }
};

int main(){
	cin >> n;
	unionFind dsu(n+1);
	int ans = n;
	fore(i, 1, n+1){
        // i se va a conectar con x
		int x; 
        cin >> x;
		if(dsu.join(i, x)){ 
		    ans--;
		}
	}
	cout << ans;
}