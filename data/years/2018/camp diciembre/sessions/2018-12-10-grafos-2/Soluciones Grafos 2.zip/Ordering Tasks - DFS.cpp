#include <bits/stdc++.h>
#define PI                acos(-1)
#define pb                push_back
#define mp                make_pair
#define all(a)            (a).begin(), (a).end()
#define clr(a,h)          memset(a, (h), sizeof(a))
#define F first
#define S second

using namespace std;

typedef vector<int>     vi;

vi topSort;
bool vis[110];
int gradoEntrada[110]; // siempre debemos empezar el topological sort
					   // desde un nodo que tenga grado de entrada = 0

vector<vi> adjList;

void DFS(int nodo)
{
	vis[nodo] = true;
	for (int i = 0; i < adjList[nodo].size(); i++)
	{
		int vecino = adjList[nodo][i];
		if (vis[vecino] == false)
		{
			DFS(vecino);
		}
	}
	topSort.push_back(nodo); // solo esto nos da el topological sort!
}

int main()
{
    std::ios::sync_with_stdio(false); cin.tie(0);
    //freopen("","r",stdin);
    //freopen("","w",stdout);
    int n, m;
    while (cin >> n >> m)
    {
    	if (n == 0 && m == 0) break;
    	adjList.clear();
    	adjList.resize(n);
    	memset( gradoEntrada, 0, sizeof( gradoEntrada ) );
    	
    	while (m--)
    	{
    		int a, b;
    		cin >> a >> b;
    		a--; b--; // index 0
    		adjList[a].pb(b);
    		gradoEntrada[b]++;
    	}

    	topSort.clear();
    	memset( vis, false, sizeof(vis) );
    	for (int i = 0; i < n; i++)
    	{
    		if (gradoEntrada[i] == 0) DFS(i);
    	}
    	
    	for (int i = topSort.size()-1; i >= 0; i--)
    	{
    		cout << topSort[i]+1 << ' ';
    	}
    	cout << '\n';
    }
    return 0;
}
// PLUS ULTRA!