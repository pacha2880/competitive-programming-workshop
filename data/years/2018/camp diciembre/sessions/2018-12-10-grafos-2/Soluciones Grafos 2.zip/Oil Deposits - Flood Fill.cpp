#include <bits/stdc++.h>
#define PI                acos(-1)
#define pb                push_back
#define mp                make_pair
#define all(a)            (a).begin(), (a).end()
#define clr(a,h)          memset(a, (h), sizeof(a))
#define F first
#define S second
int faster_in(){int r=0,c;for(c=getchar();c<=32;c=getchar());if(c=='-') return -faster_in();for(;c>32;r=(r<<1)+(r<<3)+c-'0',c=getchar());return r;}

using namespace std;

typedef long long       ll;
typedef pair<int, int>  ii;
typedef vector<int>     vi;
typedef vector<ii>      vii;
typedef vector<ll>      vll;
const int INF = int(1e9 + 7);

int Y, X; // Como las matrices son [fila][columna] yo uso [y][x]
char M[110][110];
bool vis[110][110];

bool validPos(int y, int x)
{
	// esta funcion es para verificar
	// si una posicion esta dentro del mapa
	if (y < 0 || x < 0 || y >= Y || x >= X) return false;
	return true;
}

// Las 8 direcciones adyacentes
int dy[8] = {-1, 0,+1,-1,+1,-1, 0,+1};
int dx[8] = {-1,-1,-1, 0, 0,+1,+1,+1};

void DFS( int y, int x )
{
	vis[y][x] = true;
	for (int i = 0; i < 8; i++)
	{
		int a, b;
		a = y + dy[i];
		b = x + dx[i];
		if (validPos(a, b) == false) continue;
		if (vis[a][b] || M[a][b] == '*') continue;
		DFS(a, b);
	}
}

int main()
{
    std::ios::sync_with_stdio(false); cin.tie(0);
    //freopen("","r",stdin);
    //freopen("","w",stdout);
	while (cin >> Y >> X)
	{
		if (Y == 0 && X == 0) break;
		for (int i = 0; i < Y; i++)
		{
			for (int j = 0; j < X; j++)
			{
				cin >> M[i][j];
			}
		}
		clr(vis, false); // es mi macro para memset

		int islas = 0;

		for (int i = 0; i < Y; i++)
		{
			for (int j = 0; j < X; j++)
			{
				// Un DFS cada que encuentro un nuevo componente
				if (vis[i][j] == false && M[i][j] == '@')
				{
					DFS(i, j);
					islas++;
				}
			}
		}
		cout << islas << '\n';
	}
    return 0;
}
// PLUS ULTRA!