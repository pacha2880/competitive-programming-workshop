#include <bits/stdc++.h>
#define tam 123456
#define pb push_back
using namespace std;
vector<int> grafo[tam];
int gradoentrada[tam];
void limpiar()
{
    for (int i = 0; i < tam; ++i)
        {
            grafo[i].clear();
            gradoentrada[i]=0;
        }
        
}
int main()
{
    limpiar();
    int n,m;
    while (cin >> n >> m)
    {
        if (n == 0 && m == 0) break;
        limpiar();
        int nodoa,nodob;
        for(int a=0;a<m;a++)
        {
            cin>>nodoa>>nodob;
            grafo[nodoa].pb(nodob);
            gradoentrada[nodob]++;
        }
        queue<int> cola; //priority_queue para tener el minimo/maximo lexicograficamente
        for(int a=1;a<=n;a++)
        {
            if (gradoentrada[a]==0)
            {
                cola.push(a);
            }
        }
        vector<int> toposort;
        int num,auxnum;
        while(!cola.empty())
        {
            num=cola.front();cola.pop();
            toposort.pb(num);
            for(int a=0;a<grafo[num].size();a++)
            {
                auxnum=grafo[num][a];
                gradoentrada[auxnum]--;
                if (gradoentrada[auxnum]==0)
                {
                    cola.push(auxnum);
                }
            }
        }
        for(int a=0;a<toposort.size();a++)
        {
            cout<<toposort[a]<<" ";
        }
        cout<<endl;
    }
}
