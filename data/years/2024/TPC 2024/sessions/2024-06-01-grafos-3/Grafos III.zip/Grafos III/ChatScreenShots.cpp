#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 
 
const ll N = 2e5+10;
ll n,k;
vector<ll> adj[N];
vector<ll> in(N);
bool vis[N];
 
int main(){
    fast_cin();
    int t; cin>>t;
    while(t--){
        ll n,k; cin>>n>>k;
        forn(i,n){
            adj[i].clear();
            in[i] = 0;
        }
        forn(i,k){
            ll last = -1;
            forn(j,n){
                ll num; cin>>num;
                num--;
                if(j == 0 || j == 1){
                    last = num;
                    continue;
                }
                adj[last].pb(num);
                in[num]++;
                last = num;
            }
        }
        bool bo = 1;
        queue<ll> cola;
        forn(i,n){
            if(in[i] == 0){
                cola.push(i);
            }
        }
        while(!cola.empty()){
            ll curr = cola.front();
            cola.pop();
            for(auto x: adj[curr]){
                in[x]--;
                if(in[x] == 0) cola.push(x);
            }
        }
        forn(i,n){
            if(in[i] != 0){
                bo = 0;
                break;
            }
        }
        if(bo) cout<<"YES"<<endl;
        else cout<<"NO"<<endl;
    }
    return 0;
}