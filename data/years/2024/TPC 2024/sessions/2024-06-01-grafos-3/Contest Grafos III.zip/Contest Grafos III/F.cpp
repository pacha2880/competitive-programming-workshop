#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 
const int N = 1e5;
vector<int> adj1[N], adj2[N];
bool vis[N];
 
void dfs(int s){
    if(vis[s]) return;
    vis[s] = true;
    for(auto u:adj1[s]){
        dfs(u);
    }
}
 
void dfs2(int s){
    if(vis[s]) return;
    vis[s] = true;
    for(auto u:adj2[s]){
        dfs2(u);
    }
}
 
int main(){
    fast_cin();
    //freopen("input.in", "r", stdin);
    //freopen("output.out", "w", stdout);
    int n,m; cin>>n>>m;
    forn(i,m){
        int a,b; cin>>a>>b;
        a--; b--;
        adj1[a].pb(b);
        adj2[b].pb(a);
    }
    dfs(0);
    forn(i,n){
        if(!vis[i]){
            cout<<"NO"<<endl;
            cout<<i<<" "<<i+1<<endl;
            return 0;
        }
    }
    forn(i,n) vis[i] = 0;
    dfs2(0);
    forn(i,n){
        if(!vis[i]){
            cout<<"NO"<<endl;
            cout<<i+1<<" "<<i<<endl;
            return 0;
        }
    }
    cout<<"YES"<<endl;
    return 0;
}
