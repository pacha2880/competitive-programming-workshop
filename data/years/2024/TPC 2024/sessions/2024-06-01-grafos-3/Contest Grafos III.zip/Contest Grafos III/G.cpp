#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 
vector<vector<int>> adj, adj_rev;
vector<bool> used;
vector<int> order, component;

void dfs1(int v) {
    used[v] = true;

    for (auto u : adj[v])
        if (!used[u])
            dfs1(u);

    order.pb(v);
}

void dfs2(int v) {
    used[v] = true;
    component.pb(v);

    for (auto u : adj_rev[v])
        if (!used[u])
            dfs2(u);
}


int main(){
    fast_cin();
    ll n,m; cin>>n>>m;
    adj.resize(n); adj_rev.resize(n);
    forn(i,m){
        ll a,b; cin>>a>>b;
        a--; b--;
        adj[a].pb(b);
        adj_rev[b].pb(a);
    }
    used.assign(n, false);
    forn(i,n){
        if (!used[i])
            dfs1(i);
    }
    used.assign(n, false);
    reverse(all(order));
    ll reinos = 0;
    vector<ll> ans(n);
    for (auto v : order) {
        if (!used[v]) {
            dfs2(v);
            reinos++;
            for(auto u:component){
                ans[u] = reinos;
            }
            component.clear();
        }
    }
    cout<<reinos<<endl;
    for(auto u:ans){
        cout<<u<<" ";
    }
    return 0;
}


