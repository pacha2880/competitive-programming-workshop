#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 
vector<vector<ll>> adj;

int main(){
    fast_cin();
    int t; cin>>t;
    int casos = 1;
    while(t--){
        ll n,r; cin>>n>>r;
        adj.resize(n);
        forn(i,n) adj[i].clear();
        vector<ll> in(n);
        forn(i,r){
            ll a,b; cin>>a>>b;
            adj[b].pb(a);
            in[a]++;
        }
        queue<ll> cola;
        vector<ll> rango(n);
        vector<pair<ll, ll>> ans;
        for(int i = 0; i < n; i++){
            if(in[i] == 0){
                cola.push(i);
                rango[i] = 1;
                ans.pb({rango[i], i});
            }
        }
        while(!cola.empty()){
            ll u = cola.front();
            cola.pop();
            for(auto v: adj[u]){
                in[v]--;
                if(in[v] == 0){
                    cola.push(v);
                    rango[v] = rango[u]+1;
                    ans.pb({rango[v], v});
                }
            }
        }
        cout<<"Scenario #"<<casos<<":"<<endl;
        if(sz(ans) == n){
            sort(all(ans));
            for(auto x: ans){
                cout<<x.fi<<" "<<x.se<<endl;
            }
        }
        casos++;
    }
    return 0;
}


