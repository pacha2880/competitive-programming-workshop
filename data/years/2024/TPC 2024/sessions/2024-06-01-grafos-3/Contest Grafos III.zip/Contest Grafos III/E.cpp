#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;

const ll N = 2e5+10;
char ans[N];
ll n,m,numcomp = 0;

vector<vector<int>> adj(N), adj_rev(N), adj_comp(N), SCC(N);
vector<bool> used(N);
vector<int> order, component, root(N);
ll in[N];

int flip(int x){
    return (x&1)?x+1:x-1;
}

void add_edge(char c1, int a, char c2, int b){
    a = 2*a - (c1 == '-');
    b = 2*b - (c2 == '-');
    adj[flip(a)].pb(b);
    adj[flip(b)].pb(a);
    adj_rev[b].pb(flip(a));
    adj_rev[a].pb(flip(b));
}

void dfs1(int v) {
    used[v] = true;

    for (auto u : adj[v])
        if (!used[u])
            dfs1(u);

    order.pb(v);
}

void dfs2(int v) {
    used[v] = true;
    component.pb(v);

    for (auto u : adj_rev[v])
        if (!used[u])
            dfs2(u);
}

int main(){
    fast_cin();
    int t; cin>>t;
    int casos = 1;
    while(t--){
        cin>>n>>m;
        for(int i = 0; i <= 2*n; i++){
            adj[i].clear();
            adj_rev[i].clear();
            adj_comp[i].clear();
            SCC[i].clear();
            in[i] = 0;
            root[i] = 0;
        }
        for(int i = 0; i < m; i++){
            char c1,c2; ll a,b; 
            cin>>a>>b;
            if(a < 0){
                a = -a;
                c1 = '-';
            }else c1 = '+';
            if(b < 0){
                b = -b;
                c2 = '-';
            }else c2 = '+';
            add_edge(c1,a,c2,b);
        }
        used.assign(2*n+5, false);
        for (int i = 1; i <= 2*n; i++){
            if (!used[i]){
                dfs1(i);
            }
        }
        used.assign(2*n+5, false);
        reverse(order.begin(), order.end());
        for (auto v : order){
            if (!used[v]){
                dfs2(v);
                numcomp++;
                for(auto x: component){
                    root[x] = numcomp;
                }
                component.clear();
            }
        }
        bool bo = 1;
        for(int i = 1; i <= n; i++){
            if(root[2*i] == root[2*i-1]){
                bo = 0;
            }
        }
        cout<<"Case "<<casos<<": ";
        if(bo) cout<<"Yes"<<endl;
        else cout<<"No"<<endl;
        casos++;
    }
    return 0;
}


