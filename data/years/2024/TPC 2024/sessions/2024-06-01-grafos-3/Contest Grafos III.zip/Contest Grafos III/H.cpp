#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 
const int N = 1e5+5; 
vector<vector<int>> adj(N);
vector<ll> vis(N);

void dfs(int s){
    for(auto u: adj[s]){
        if(vis[u] == 1) continue;
        vis[u] = 1;
        dfs(u);
    }
}


int main(){
    fast_cin();
    ll n,m; cin>>n>>m;
    vector<ll> in(n);
    forn(i,n) in[i] = 0, vis[i] = 0;
    forn(i,m){
        ll a,b; cin>>a>>b;
        a--; b--;
        adj[a].pb(b);
        in[b]++;
    }
    vis[0] = 1;
    dfs(0);
    if(vis[n-1] == 0){
        cout<<"IMPOSSIBLE"<<endl;
        return 0;
    }
    queue<ll> cola;
    vector<ll> distmax(n,-1);
    bool bo = 0;
    forn(i,n){
        if(in[i] == 0){
            cola.push(i);
        }
    }
    bo = 0;
    distmax[0] = 0;
    vector<ll> padre(n,-1);
    while(!cola.empty()){
        ll u = cola.front();
        cola.pop();
        for(auto v : adj[u]){
            if(distmax[u] != -1 && distmax[u]+1 > distmax[v]){
                distmax[v] = distmax[u]+1;
                padre[v] = u;
            }
            in[v]--;
            if(in[v] == 0){
                cola.push(v);
            }
        }
    }
    ll cant = distmax[n-1] - distmax[0];
    cout<<cant+1<<endl;
    vector<ll> res;
    ll u = n-1;
    forn(i,cant+1){
        res.pb(u+1);
        u = padre[u];
    }
    reverse(all(res));
    for(auto u: res){
        cout<<u<<" ";
    }
    return 0;
}


