#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 

int main(){
    fast_cin();
    int n; cin>>n;
    vector<string> pals(n);
    forn(i,n) cin>>pals[i];
    vector<vector<int>> adj(26);
    vector<int> in(26, 0);
    for(int i = 1; i < n; i++){
        int aux = 0;
        int minlen = min(pals[i].size(), pals[i-1].size());
        while(aux < minlen && pals[i][aux] == pals[i-1][aux]) aux++;
        if(aux == minlen){
            if(pals[i].size() < pals[i-1].size()){
                cout<<"Impossible"<<endl;
                return 0;
            }
        }else{
            adj[pals[i-1][aux]-'a'].pb(pals[i][aux]-'a');
            in[pals[i][aux]-'a']++;
        }
    }
    queue<int> cola;
    vector<int> ans;
    forn(i,26){
        if(in[i] == 0){
            cola.push(i);
        }
    }
    while(!cola.empty()){
        int u = cola.front();
        cola.pop();
        ans.pb(u);
        for(auto v: adj[u]){
            in[v]--;
            if(in[v] == 0){
                cola.push(v);
            }
        }
    }
    if(sz(ans) != 26){
        cout<<"Impossible"<<endl;
        return 0;
    }
    forn(i,26){
        cout<<char(ans[i]+'a');
    }
    cout<<endl;
    return 0;
}


