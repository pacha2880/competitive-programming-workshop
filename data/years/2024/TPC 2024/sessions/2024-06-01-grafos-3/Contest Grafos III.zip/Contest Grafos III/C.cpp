#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 
vector<vector<int>> adj, adj_rev;
vector<bool> used;
vector<int> order, component;

void dfs1(int v) {
    used[v] = true;

    for (auto u : adj[v])
        if (!used[u])
            dfs1(u);

    order.pb(v);
}

void dfs2(int v) {
    used[v] = true;
    component.pb(v);

    for (auto u : adj_rev[v])
        if (!used[u])
            dfs2(u);
}

int main(){
    fast_cin();
    ll n,m; 
    while(cin>>n>>m && (n || m)){
        adj.clear(); adj_rev.clear(); used.clear(); order.clear(); component.clear();
        adj.resize(n); adj_rev.resize(n);
        forn(i,m){
            ll a,b,c; cin>>a>>b>>c;
            a--; b--;
            if(c == 1){
                adj[a].pb(b);
                adj_rev[b].pb(a);
            }else{
                adj[a].pb(b);
                adj[b].pb(a);
                adj_rev[b].pb(a);
                adj_rev[a].pb(b);
            }
        }
        used.assign(n, false);
        for (int i = 0; i < n; i++){
            if (!used[i])
                dfs1(i);
        }
        used.assign(n, false);
        reverse(order.begin(), order.end());
        vector<int> ans;
        int cont = 0;
        for (auto v : order){
            if (!used[v]) {
                dfs2 (v);
                cont++;
                component.clear();
            }
        }
        if(cont == 1) cout<<1<<endl;
        else cout<<0<<endl;
    }
    return 0;
}


