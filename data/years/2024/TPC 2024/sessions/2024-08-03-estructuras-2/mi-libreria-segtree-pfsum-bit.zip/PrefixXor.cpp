// Same as prefix sum,but with operator xor
void test_case() {
    ll n, q;
    cin >> n >> q;
    vl nums(n), pf(n+1);
    for (int i =0;i<n;i++) cin >> nums[i], pf[i+1] = pf[i] ^ nums[i];
    for (int i=0;i<q;i++) {
        ll x, y;
        cin >> x >> y;
        cout << (pf[y] ^ pf[x-1]) << "\n";
    }
}
