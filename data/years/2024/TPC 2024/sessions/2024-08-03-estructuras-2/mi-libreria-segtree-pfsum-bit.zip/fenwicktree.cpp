// Fenwick Tree 0-index
// Tener cuidado con la precision, usar para mayor precision #define int long long 
struct FenwickTree {
    vector<int> bit; 
    int n;
 
    FenwickTree(int n) {
        this->n = n;
        bit.assign(n, 0);
    }
 
    FenwickTree(vector<int> a) : FenwickTree(a.size()) {
        for (size_t i = 0; i < a.size(); i++)
            add(i, a[i]);
    }
 	
    // Returns the prefix sum of from a_0 to a_r (0 index)
    int sum(int r) {
        int ret = 0;
        for (; r >= 0; r = (r & (r + 1)) - 1)
            ret += bit[r];
        return ret;
    }
 
    // Returns the sum from l to r
    int sum(int l, int r) {
        return sum(r) - sum(l - 1);
    }
    
    // Add a delta value to a_idx (0 index)
    void add(int idx, int delta) {
        for (; idx < n; idx = idx | (idx + 1))
            bit[idx] += delta;
    }
};
