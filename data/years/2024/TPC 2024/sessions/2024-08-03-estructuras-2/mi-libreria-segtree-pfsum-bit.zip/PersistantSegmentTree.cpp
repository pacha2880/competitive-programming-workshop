// Tal vez lo necesiten en un futuro
// Es un Persintente es que puedes volver a cualquier estado anterior del segment tree y 
// usarlo tal cual como un segment tree
// Pueden probarlo en https://cses.fi/problemset/task/1737

/* 
La forma de usarlo es

void test_case() {
    ll n, q;
    cin >> n >> q;
    vector<Vertex*> trees;
    vl initial(n);
    for (int i =0;i<n;i++) {
        cin >> initial[i];
    }
    trees.pb(build(initial));
 
    for (int i =0;i<q;i++) {
        ll t;
        cin >> t;
        if (t == 1) {
            ll a,k,x;
            cin >>k>>a>>x;
            a--,k--;
            trees[k] = update(trees[k],n,a,x);
        } else if (t == 2) {
            ll a, b,k;
            cin >>k>>a>>b;a--,b--,k--;
            cout << get_sum(trees[k],n,a,b) << "\n";
        } else {
            ll k;
            cin >> k;k--;
            trees.pb(copy(trees[k]));
        }
    }

*/

struct Vertex {
    Vertex *l, *r;
    ll sum;
    Vertex(int val) : l(nullptr), r(nullptr), sum(val) {}
    Vertex(Vertex *l, Vertex *r) : l(l), r(r), sum(0) {
        if (l) sum += l->sum;
        if (r) sum += r->sum;
    }
};
Vertex* build(vector<ll>& a, int tl, int tr) {
    if (tl == tr)
        return new Vertex(a[tl]);
    int tm = (tl + tr) / 2;
    return new Vertex(build(a, tl, tm), build(a, tm+1, tr));
}
ll get_sum(Vertex* v, int tl, int tr, int l, int r) {
    if (l > r)
        return 0;
    if (l == tl && tr == r)
        return v->sum;
    int tm = (tl + tr) / 2;
    return get_sum(v->l, tl, tm, l, min(r, tm))
         + get_sum(v->r, tm+1, tr, max(l, tm+1), r);
}
Vertex* update(Vertex* v, int tl, int tr, int pos, int new_val) {
    if (tl == tr)
        return new Vertex(new_val);
    int tm = (tl + tr) / 2;
    if (pos <= tm)
        return new Vertex(update(v->l, tl, tm, pos, new_val), v->r);
    else
        return new Vertex(v->l, update(v->r, tm+1, tr, pos, new_val));
}
Vertex* build(vector<ll> &a) {
    return build(a,0,a.size()-1);
}
ll get_sum(Vertex *v,ll n,int l, int r) {
    return get_sum(v,0,n-1,l,r);
}
Vertex* update(Vertex* v,ll n, int pos, int newV) {
    return update(v,0,n-1,pos,newV);
}
Vertex* copy(Vertex* v) {
    return new Vertex(v->l,v->r);
}
