void test_case() {
    ll n, q;
    cin >> n >> q;
    vector<string> s(n); // entrada 0-indexed
    for (int i =0;i<n;i++) {
        cin >> s[i];
    }

    vector<vl> pf(n+1,vl(n+1)); // 1-indexed
    for (int i =0;i<n;i++) {
        for (int j = 0;j<n;j++) {
            ll v = s[i][j] == '*'; // v is the value of the matrix at i,j
            pf[i+1][j+1] = v + pf[i][j+1] + pf[i+1][j] - pf[i][j];
        }
    }
    while (q--) {
        ll y1,x1,y2,x2;
        cin >>x1>>y1>>x2>>y2;
        y1--,x1--,y2--,x2--;

        ll sum = pf[x2+1][y2+1]-pf[x1][y2+1]-pf[x2+1][y1]+pf[x1][y1];// query using 0 indexed
        cout << sum << "\n";
    }
 
}
