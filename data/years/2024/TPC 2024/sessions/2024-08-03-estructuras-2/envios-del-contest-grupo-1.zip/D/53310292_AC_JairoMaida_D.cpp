/*
$$$$$$$\   $$$$$$\  $$\      $$\ $$$$$$$\   $$$$$$\
$$  __$$\ $$  __$$\ $$$\    $$$ |$$  __$$\ $$  __$$\
$$ |  $$ |$$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ /  $$ |
$$$$$$$\ |$$ |  $$ |$$\$$\$$ $$ |$$$$$$$\ |$$$$$$$$ |
$$  __$$\ $$ |  $$ |$$ \$$$  $$ |$$  __$$\ $$  __$$ |
$$ |  $$ |$$ |  $$ |$$ |\$  /$$ |$$ |  $$ |$$ |  $$ |
$$$$$$$  | $$$$$$  |$$ | \_/ $$ |$$$$$$$  |$$ |  $$ |
\_______/  \______/ \__|     \__|\_______/ \__|  \__|
*/
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<ll> vll;
typedef pair<ll, ll> pll;

#define ft first
#define sd second
#define pb push_back
#define forn(i, n) for (ll i = 0; i < n; i++)
#define rfor(i, n) for (ll i = n - 1; i >= 0; i--)

#pragma GCC optimization("O2")

int main()
{

    ios::sync_with_stdio(0);
    cin.tie(0);

    ll n = 0, q = 0;

    cin >> n >> q;

    vector<vector<ll>> mat(n, vector<ll>(n, 0));

    forn(i, n)
    {
        forn(j, n)
        {
            char c = 'a';
            cin >> c;
            if (c == '*')
            {
                mat[i][j] = 1;
            }
            else
            {
                mat[i][j] = 0;
            }
        }
    }

    vector<vector<ll>> ps(n + 1, vector<ll>(n + 1, 0));

    forn(i, n)
    {
        forn(j, n)
        {
            ps[i + 1][j + 1] = ps[i][j + 1] + ps[i + 1][j] - ps[i][j] + mat[i][j];
        }
    }

    forn(i, q)
    {
        ll x1 = 0, y1 = 0, x2 = 0, y2 = 0;

        cin >> x1 >> y1 >> x2 >> y2;

        cout << ps[x2][y2] - ps[x1 - 1][y2] - ps[x2][y1 - 1] + ps[x1 - 1][y1 - 1];
        cout << "\n";
    }

    return 0;
}