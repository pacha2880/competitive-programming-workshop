#include <bits/stdc++.h>
#include <sstream>
#include <iomanip> 
 
#define int ll
#define mp make_pair
#define pb push_back
#define all(a) (a).begin(), (a).end()
#define floatigual(a, b) (fabs(a - b) < EPS)
#define mod(a) md(a, MOD)
#define FOR(i, n) for (int i = 0; i < (n); ++i)
#define FOR3(i, a, b) for (int i = (a); i < (b); ++i)
#define FORD(i, n) for (int i = (n) - 1; i >= 0; --i)
#define FORDD(i, a, b) for (int i = (b) - 1; i >= (a); --i)
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<ll> vlolo;
 
const int tam = 200010;
//const int MOD = 1000000007;
const int MOD1 = 998244353;
const double DINF = 1e100;
const double EPS = 1e-9;
const double PI = acos(-1);
const int big = 10000000;
const int mod = 1e9 + 7;
const int p = 27;
const string cadena = "314159265358979323846264338327";
const string larga = "YesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYes";
const int MOD =  1e9 +7;
const int maxN = 1e6+2;
const int MODP = 1e1;
const int maxP = 1e1+7;
const int tami = 20000008;

//int pascal[maxP+2][maxP+2];
/**
* Ganar tambien significa acabar con los suenos de otro :c:
*/
/**
* Morir en el intento o morirme intentando?
*/
int lsb(int x) {return x & -x;}
template <typename T>
struct FenwickTree{
       vector<T> bit;
        FenwickTree(int N): bit(N+1, 0) {};
       void add(int i, T val){
             while(i < bit.size()){
                   bit[i] += val;
                   i += lsb(i);
             }
       }
       T sum(int i){
             T ret = 0;
             while(i > 0){
              ret += bit[i];
              i -= lsb(i);
             }
             return ret;
       }
       T sum(int l, int r){
         return sum(r)-sum(l-1);
       }
};

void mapeador(vector<int>& arr){
     vector<int> aux = arr;
     sort(all(aux));
     int act = 1;
     map<int, int> m;
     for(int &x: aux){
         if(m.find(x) == m.end()){
            m[x] = act++;
         }
     }
     FOR(i, arr.size()){
         arr[i] = m[arr[i]];
     }
}
/*
void solve(){ 
    int l = 2, r = 999;
    int res = 0;
    while(l <= r){
          int m = l + (r-l)/2;
          cout<<"? "<<1<< " "<<m<<endl;;
          fflush(stdout);
          int area; cin>>area;
          if(area == m){
            l = m + 1;
        }else{
            res = m;
            r = m - 1;
        }
    }
    cout<<"! "<<res<<endl;
    fflush(stdout);
}
*/

/*
void solve(){
     int n,q; cin>>n>>q;
     vi prefix(n+1);
     for(int i = 1; i <= n; i++){
         int x; cin>>x;
        prefix[i] = prefix[i-1]+x;
     }
     while(q--){
           int a,b; cin>>a>>b;
           cout<<prefix[b]-prefix[a-1]<<endl;
     }
}
*/


void solve() {
    int n, q;
    cin >> n >> q;
    vi prefix(n + 1, 0);
    FOR3(i, 1, n + 1) {
        int x;
        cin >> x;
        prefix[i] = prefix[i - 1] + x;
        }
    while (q--) {
        int a, b;
        cin >> a >> b;
        cout << prefix[b] - prefix[a - 1] << endl;
    }
}


signed main(){
    ios::sync_with_stdio(0); 
    cin.tie(0); cout.tie(0);
    //int t; cin>>t;while(t--)
    solve();
}