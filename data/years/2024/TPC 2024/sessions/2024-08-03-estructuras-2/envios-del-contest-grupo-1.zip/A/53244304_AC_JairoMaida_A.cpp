/*
$$$$$$$\   $$$$$$\  $$\      $$\ $$$$$$$\   $$$$$$\
$$  __$$\ $$  __$$\ $$$\    $$$ |$$  __$$\ $$  __$$\
$$ |  $$ |$$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ /  $$ |
$$$$$$$\ |$$ |  $$ |$$\$$\$$ $$ |$$$$$$$\ |$$$$$$$$ |
$$  __$$\ $$ |  $$ |$$ \$$$  $$ |$$  __$$\ $$  __$$ |
$$ |  $$ |$$ |  $$ |$$ |\$  /$$ |$$ |  $$ |$$ |  $$ |
$$$$$$$  | $$$$$$  |$$ | \_/ $$ |$$$$$$$  |$$ |  $$ |
\_______/  \______/ \__|     \__|\_______/ \__|  \__|
*/
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;

#define ft first
#define sd second
#define pb push_back
#define forn(i, n) for (int i = 0; i < n; i++)
#define rfor(i, n) for (int i = n - 1; i >= 0; i--)

#pragma GCC optimization("O2")

int main()
{

    ios::sync_with_stdio(0);
    cin.tie(0);

    ll n = 0, q = 0;
    cin >> n >> q;
    vector<ll> v(n, 0);
    for (ll i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    vector<ll> ps(n + 1, 0);

    forn(i, n)
    {
        ps[i + 1] = v[i] + ps[i];
    }

    forn(i, q)
    {
        ll l = 0, r = 0;
        cin >> l >> r;
        cout << ps[r] - ps[l - 1];
        cout << "\n";
    }

    return 0;
}