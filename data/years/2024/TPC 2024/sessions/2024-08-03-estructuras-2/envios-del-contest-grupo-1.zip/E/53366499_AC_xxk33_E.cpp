#include <bits/stdc++.h>

#define int                 ll
#define mp                  make_pair
#define pb                  push_back
#define all(a)              (a).begin(), (a).end()
#define sz(a)               (int)a.size()
#define mod(a)              md(a, MOD)
#define srt(a)              sort(all(a))
#define mem(a, h)           memset(a, (h), sizeof(a))
#define forn(i, n)          for(int i = 0; i < n; i++)
#define fore(i, b, e)       for(int i = b; i < e; i++)
#define forev(i, e, b)      for(int i = e; i > b; i--)
#define forg(i, b, e, m)    for(int i = b; i < e; i+=m)
#define index               int mid = (b + e) / 2, l = node * 2 + 1, r = l + 1;
#define DBG(x)              cerr<<#x<<" = "<<(x)<<endl
#define RAYA                cout<<"=============================="<<'\n'
#define fast                ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

using namespace std;

typedef long long                   ll;
typedef long double                 ld; 
typedef unsigned long long          ull;
typedef pair<int, int>              ii;
typedef pair<pair<int, int>, int>   iii;
typedef vector<int>                 vi;
typedef vector<ii>                  vii;
typedef vector<ll>                  vll;

const int tam       =   200010;
const int MOD       =   1000000007;
const int MOD1      =   998244353;
const double DINF   =   1e100;
const double EPS    =   1e-9;
const double PI     =   acos(-1);
int cases           =   0;

//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

vector<int>a;

struct tree {
    int n;
    vector<int> tree;

    void init(int nn) {
        n = nn;
        tree.clear();
        int aux = ceil(log2(nn)); 
        int tam = pow(2, aux);
        tree.resize(2 * tam - 1, INT32_MAX);
    }

    void build(int ind, int low, int high) {
        if (low == high) {
            tree[ind] = a[low];
            return;
        }
        int mid = (low + high) / 2;
        build(2 * ind + 1, low, mid);
        build(2 * ind + 2, mid + 1, high);
        tree[ind] = min(tree[2 * ind + 1], tree[2 * ind + 2]);
    }

    int query(int ind, int low, int high, int l, int r) {
        if (low >= l && high <= r) return tree[ind];
        if (high < l || low > r) return INT32_MAX;

        int mid = (low + high) / 2;
        int left = query(2 * ind + 1, low, mid, l, r);
        int right = query(2 * ind + 2, mid + 1, high, l, r);
        return min(left, right);
    }

    void update(int ind, int low, int high, int pos, int value) {
        if (low == high) {
            tree[ind] = value;
            return;
        }
        int mid = (low + high) / 2;
        if (pos <= mid)
            update(2 * ind + 1, low, mid, pos, value);
        else
            update(2 * ind + 2, mid + 1, high, pos, value);
        tree[ind] = min(tree[2 * ind + 1], tree[2 * ind + 2]);
    }

    void build(int size) {
        init(size);  
        build(0, 0, size - 1);
    }

    int query(int l, int r) {
        return query(0, 0, n - 1, l, r);
    }

    void update(int pos, int diff) {
        update(0, 0, n - 1, pos, diff);
    }
};

void solve() {
    int n, q;
    tree s1;
    cin>>n>>q;
    a.resize(n);
    for (int i = 0; i < n; i++) {
        cin>>a[i];
    }
    s1.build(n); 
    for(int i = 0; i < q; i++) {
        int k,a,b;
        cin>>k>>a>>b;
        if (k==1) {
            s1.update(a-1,b);
        } else {
            cout<<s1.query(a-1,b-1)<<endl;
        }
    }
}

signed main(){
    fast;
    int tt=1;
    // cin>>tt;
    while(tt--){
        cases++;
        solve();
    }
    return 0;
}
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

// Se vuelve mas facil, cada dia es un poco mas facil,
// pero tienes que hacerlo cada dia, es la parte dificil, pero se vuelve mas facil.
// Crecer duele.
// La unica manera de pasar esa barrera es pasandola.
// No sirve de nada hacer sacrificios si no tienes disciplina.
// Si te caes 7 veces, levantate 8.
// LA DISCIPLINA es el puente entre tus metas y tus logros.
// Las indisciplinadas son mi debilidad.
// Take a sad song and make it better.