#include <bits/stdc++.h>
using namespace std;
 
#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()
#define sortt(x) sort(all(x))
#define sq(a) ((a) * (a))
 
#define each(x, xs)  for (auto &x : (xs))
#define rep(i, be, en) for (__typeof(en) i = (be) - ((be) > (en)); i != (en) - ((be) > (en)); i += 1 - 2 * ((be) > (en)))
#define FOR(i, a, b) for (ll (i) = (a); (i) < (b); (i)++)
 
using ll = long long;
using ld = long double;
using pi = pair<int, int>;
using pl = pair<ll, ll>;
using ti = tuple<long long, long long, long long>;
using vi = vector<int>;
using vb = vector<bool>;
using vl = vector<ll>;
using vs = vector<string>;
using vvl = vector<vl>;
using vpl = vector<pl>;
template<class T> using pql = priority_queue<T,vector<T>,greater<T>>;
template<class T> using pqg = priority_queue<T>;
 
// >>>>>>>>>> debugging >>>>>>>>>>
#ifdef NICO_LOCAL
    #include "debug.h"
    #define LINE cerr << "-------------------" << endl;
#else
    #define deb(x...)
    #define LINE
#endif
// <<<<<<<<<< debugging <<<<<<<<<<
 
void test_case();
 
 
const ll INF = INT64_MAX;
const int inf = INT32_MAX;
const ld PI = acos(-1);
const int MOD = 1e9 + 7;
const int DX[4]{1,0,-1,0}, DY[4]{0,1,0,-1};
 
int testId;
 
void init();
 
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    init();
    int T;
    T = 1;
    // cin >> T;
    rep (t, 0, T) { testId++; test_case(); }
 
    return 0;
}
 
void init() {
    
}
 
struct Node {
    ll x;
};
 
const int SUM = 1;
const int SET = 2;
 
struct Func {
    ll type, value;
};
 
Node e() { // op(x, e()) = x
    return { 0 };
};
 
Func id() { // mapping(x, id()) = x
    return {SUM, 0};
}
 
Node op(Node &a, Node &b) { // associative property
    return {a.x + b.x};
}
 
Node mapping(Node node, Func &lazy, ll l, ll r) {
    ll sz = (r-l+1);
    if (lazy.type == SUM) {
        return {node.x + lazy.value*sz };
    } else {
        return {lazy.value*sz };
    }
    return node;
}
 
Func composicion(Func &prev, Func &actual) {
    if (actual.type == SET) {
        return actual;
    }
    return {prev.type, prev.value + actual.value };
}
 
struct lazytree {
    int n;
    vector<Node> nodes;
    vector<Func> lazy;
 
    void init(int nn) {
        n = nn;
        int size = 1;
        while (size < n) {
            size *= 2;
        }
        ll m = size *2;
        nodes.assign(m, e());
        lazy.assign(m, id());
    }
 
    void push(int i, int sl, int sr) {
        nodes[i] = mapping(nodes[i], lazy[i], sl, sr);
        if (sl != sr) {
            lazy[i * 2 + 1] = composicion(lazy[i*2+1],lazy[i]);
            lazy[i * 2 + 2] = composicion(lazy[i*2+2],lazy[i]);
        }
        lazy[i] = id();
    }
 
    void apply(int i, int sl, int sr, int l, int r, Func f) {
        push(i, sl, sr);
        if (l <= sl && sr <= r) {
            lazy[i] = f;
            push(i,sl,sr);
        } else if (sr < l || r < sl) {
        } else {
            int mid = (sl + sr) >> 1;
            apply(i * 2 + 1, sl, mid, l, r, f);
            apply(i * 2 + 2, mid + 1, sr, l, r, f);
            nodes[i] = op(nodes[i*2+1],nodes[i*2+2]);
        }
    }
 
    void apply(int l, int r, Func f) {
        assert(l <= r);
        assert(r < n);
        apply(0, 0, n - 1, l, r, f);
    }
 
    void update(int i, Node node) {
        assert(i < n);
        update(0, 0, n-1, i, node);
    }
 
    void update(int i, int sl, int sr, int pos, Node node) {
        if (sl <= pos && pos <= sr) {
            push(i,sl,sr);
            if (sl == sr) {
                nodes[i] = node;
            } else {
                int mid = (sl + sr) >> 1;
                update(i * 2 + 1, sl, mid, pos, node);
                update(i * 2 + 2, mid + 1, sr, pos, node);
                nodes[i] = op(nodes[i*2+1], nodes[i*2+2]);
            }
        }
    }
 
    Node query(int i, int sl, int sr, int l, int r) {
        push(i,sl,sr);
        if (l <= sl && sr <= r) {
            return nodes[i];
        } else if (sr < l || r < sl) {
            return e();
        } else {
            int mid = (sl + sr) >> 1;
            auto a = query(i * 2 + 1, sl, mid, l, r);
            auto b = query(i * 2 + 2, mid + 1, sr, l, r);
            return  op(a,b);
        }
    }
 
    Node query(int l, int r) {
        assert(l <= r);
        assert(r < n);
        return query(0, 0, n - 1, l, r);
    }
};
 
void test_case() {
    ll n, q;
    cin >> n >> q;
    lazytree tree; tree.init(n);
 
    for (int i =0;i<n;i++) {
        ll x;
        cin >> x;
        tree.update(i, {x});
    }
 
    for (int i =0;i<q;i++) {
        ll t;
        cin >> t;
        if (t == 1) {
            ll l, r, x;
            cin >> l >> r >> x;
            tree.apply(l-1,r-1,{1, x});
        } else if (t == 2) {
            ll l, r, x;
            cin >> l >> r >> x;
            tree.apply(l-1,r-1,{2, x});
        } else {
            ll l, r;
            cin >> l >> r;
            cout << tree.query(l-1,r-1).x << "\n";
        }
    }
}