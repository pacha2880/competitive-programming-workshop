#include <bits/stdc++.h>
#include <sstream>
#include <iomanip> 
 
#define int ll
#define mp make_pair
#define pb push_back
#define all(a) (a).begin(), (a).end()
#define floatigual(a, b) (fabs(a - b) < EPS)
#define mod(a) md(a, MOD)
#define FOR(i, n) for (int i = 0; i < (n); ++i)
#define FOR3(i, a, b) for (int i = (a); i < (b); ++i)
#define FORD(i, n) for (int i = (n) - 1; i >= 0; --i)
#define FORDD(i, a, b) for (int i = (b) - 1; i >= (a); --i)
 
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<ll> vlolo;
 
const int tam = 200010;
//const int MOD = 1000000007;
const int MOD1 = 998244353;
const double DINF = 1e100;
const double EPS = 1e-9;
const double PI = acos(-1);
const int big = 10000000;
const int mod = 1e9 + 7;
const int p = 27;
const string cadena = "314159265358979323846264338327";
const string larga = "YesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYesYes";
const int MOD =  1e9 +7;
const int maxN = 1e6+2;
const int MODP = 1e1;
const int maxP = 1e1+7;
const int tami = 20000008;

//int pascal[maxP+2][maxP+2];
/**
* Ganar tambien significa acabar con los suenos de otro :c:
*/
/**
* Morir en el intento o morirme intentando?
*/
//Rendirse jamas fue opcion :3

/*
vi st;
int n;

void update(int idx, int value, int v = 1, int l = 0, int r = n - 1) {
    if (l == r) 
        st[v] = value;
    else {
        int m = l + (r - l) / 2;
        if (idx <= m) update(idx, value, v * 2, l, m);
        else update(idx, value, v * 2 + 1, m + 1, r);
        st[v] = __gcd(st[v * 2] , st[v * 2 + 1]);
    }
}

int query(int l, int r, int v = 1, int sl = 0, int sr = n - 1) {
    if (sl > r || sr < l) return 0; // retornar el neutro
    if (sl >= l && sr <= r) return st[v];
    int m = sl + (sr - sl) / 2;
    return __gcd(query(l, r, v * 2, sl, m),query(l, r, v * 2 + 1, m + 1, sr));
}

vector<unordered_map<int, int>> st2;
vi nums;
void build(int v = 1, int l = 0, int r = n-1){
     if(l == r){
        st2[v][nums[l]]++;
     }else{
        int m = l + (r-l)/2;
        build(v*2, l, m);
        build(v*2+1, m+1, r);
        st2[v] = st2[v*2];
        for(auto c: st2[v*2+1]) st2[v][c.first]+=c.second;
     }
}

int query2(int l, int r, int x, int v = 1, int sl = 0, int sr = n-1){
    if(sl > r || sr < l || sl > sr) return 0;
    if(sl >= l && sr <= r){
           if(st2[v].count(x)){
              return st2[v][x];
           }else return 0;
    }
    int m = sl + (sr-sl)/2;
    return query2(l,r,x,v*2, sl, m)+query2(l, r, x, v*2+1, m+1, sr);
}

int lsb(int x) {return x & -x;}
template <typename T>
struct FenwickTree{
       vector<T> bit;
        FenwickTree(int N): bit(N+1, 0) {};
       void add(int i, T val){
             while(i < bit.size()){
                   bit[i] += val;
                   i += lsb(i);
             }
       }
       T sum(int i){
             T ret = 0;
             while(i > 0){
              ret += bit[i];
              i -= lsb(i);
             }
             return ret;
       }
       T sum(int l, int r){
         return sum(r)-sum(l-1);
       }
};

void mapeador(vector<int>& arr){
     vector<int> aux = arr;
     sort(all(aux));
     int act = 1;
     map<int, int> m;
     for(int &x: aux){
         if(m.find(x) == m.end()){
            m[x] = act++;
         }
     }
     FOR(i, arr.size()){
         arr[i] = m[arr[i]];
     }
}


void solve() {
    int t, l, r;
    cin >> n;
    st.resize(4 * n, 0);
    st2.resize(4*n);
    nums.resize(n);
    for (auto &c : nums) cin >> c;
    for (int i = 0; i < n; i++){
        update(i, nums[i]);
    }
    build(1, 0 , n-1);
    int q; cin>>q;
    for (int i = 0; i < q; i++) {
         cin>>l>>r;
         l--,r--;
         int gcd = query(l, r);
         int cont = query2(l,r,gcd);
         cout<<(r-l+1)-cont<<endl;
    }
}


*/
void solve(){
    int n; cin>>n;
      vi arr(n+1);
      string s; cin>>s;
      for(int i = 0; i < n; i++){
          arr[i+1] = arr[i]+s[i]-'0';
      }
      int ans = 0;
      map<int, int> mapa;
      mapa[0]++;
      for(int i = 1; i <= n; i++){
          ans += mapa[arr[i]-i];
          mapa[arr[i]-i]++;
      }
      cout<<ans<<endl;
}
//asdasdasdasdas
signed main() {
    ios::sync_with_stdio(0); 
    cin.tie(0); 
    cout.tie(0);
    int t; cin>>t; while(t--)
    solve();
}