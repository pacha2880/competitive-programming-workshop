/*
$$$$$$$\   $$$$$$\  $$\      $$\ $$$$$$$\   $$$$$$\
$$  __$$\ $$  __$$\ $$$\    $$$ |$$  __$$\ $$  __$$\
$$ |  $$ |$$ /  $$ |$$$$\  $$$$ |$$ |  $$ |$$ /  $$ |
$$$$$$$\ |$$ |  $$ |$$\$$\$$ $$ |$$$$$$$\ |$$$$$$$$ |
$$  __$$\ $$ |  $$ |$$ \$$$  $$ |$$  __$$\ $$  __$$ |
$$ |  $$ |$$ |  $$ |$$ |\$  /$$ |$$ |  $$ |$$ |  $$ |
$$$$$$$  | $$$$$$  |$$ | \_/ $$ |$$$$$$$  |$$ |  $$ |
\_______/  \______/ \__|     \__|\_______/ \__|  \__|
*/
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<ll> vll;
typedef pair<ll, ll> pll;

#define ft first
#define sd second
#define pb push_back
#define forn(i, n) for (ll i = 0; i < n; i++)
#define rfor(i, n) for (ll i = n - 1; i >= 0; i--)

#pragma GCC optimization("O2")

int main()
{

    ios::sync_with_stdio(0);
    cin.tie(0);

    ll t = 0;
    cin >> t;

    while (t--)
    {
        ll n = 0;
        cin >> n;
        vll v(n);

        forn(i, n)
        {
            char aux;
            cin >> aux;
            v[i] = aux - '0';
            // cout << "v[" << i << "]: " << v[i] << "\n";
        }

        vll ps(n + 1, 0);
        map<ll, ll> m;
        ll sum = 0;
        forn(i, n)
        {
            ps[i + 1] = v[i] + ps[i];
            if (m.count(ps[i] + 1 - i) > 0)
            {
                m[ps[i] + 1 - i]++;
            }
            else
            {
                m[ps[i] + 1 - i] = 1;
            }

            if (m.count(ps[i + 1] - i) > 0)
            {
                sum += m[ps[i + 1] - i];
            }
        }

        cout << sum;
        cout << "\n";
    }

    return 0;
}