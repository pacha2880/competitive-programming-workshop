#include <bits/stdc++.h>

#define int                 ll
#define mp                  make_pair
#define pb                  push_back
#define all(a)              (a).begin(), (a).end()
#define sz(a)               (int)a.size()
#define mod(a)              md(a, MOD)
#define srt(a)              sort(all(a))
#define mem(a, h)           memset(a, (h), sizeof(a))
#define forn(i, n)          for(int i = 0; i < n; i++)
#define fore(i, b, e)       for(int i = b; i < e; i++)
#define forev(i, e, b)      for(int i = e; i > b; i--)
#define forg(i, b, e, m)    for(int i = b; i < e; i+=m)
#define index               int mid = (b + e) / 2, l = node * 2 + 1, r = l + 1;
#define DBG(x)              cerr<<#x<<" = "<<(x)<<endl
#define RAYA                cout<<"=============================="<<'\n'
#define fast                ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

using namespace std;

typedef long long                   ll;
typedef long double                 ld; 
typedef unsigned long long          ull;
typedef pair<int, int>              ii;
typedef pair<pair<int, int>, int>   iii;
typedef vector<int>                 vi;
typedef vector<ii>                  vii;
typedef vector<ll>                  vll;

const int tam       =   200010;
const int MOD       =   1000000007;
const int MOD1      =   998244353;
const double DINF   =   1e100;
const double EPS    =   1e-9;
const double PI     =   acos(-1);
int cases           =   0;

//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

int bit[1025][1025];
int n;

void update(int x, int y, int val){
    int y1;
    while(x <= n){
        y1 = y;
        while(y1 <= n){
            bit[x][y1] += val;
            y1 += (y1 & -y1);
        }
        x += (x & -x);
    }
}


int query(int x, int y){
    int sum = 0;
    while(x > 0){
        int y1 = y;
        while(y1 > 0){
            sum += bit[x][y1];
            y1 -= (y1 & -y1);
        }
        x -= (x & -x);
    }

    return sum;
}

int query(int x1, int y1, int x2, int y2){
    return query(x2, y2) - query(x2, y1 - 1) - query(x1 - 1, y2) + query(x1 - 1, y1 - 1);
}


void solve(){
    int q,aux;
    cin>>n>>q;
    vector<vector<int>>trees(n,vector<int>(n));
    for (int i = 0; i < n; i++){
        string s;
        cin>>s;
        for (int j = 0; j < n; j++){
            aux=0;
            if(s[j]=='*'){  
                trees[i][j]=1;
                aux=1;
            }
            // bit[i+1][j+1]=aux+bit[i+1][j]+bit[i][j+1]-bit[i][j];
            update(i + 1, j + 1, aux);
        }   
    }

    while(q--){
        int k;
        cin>>k;
        if(k==1){
            int res=1;
            int a,b;
            cin>>a>>b;
            if(trees[a-1][b-1]==0){
                trees[a-1][b-1]=1;
            }
            else{
                trees[a-1][b-1]=0;
                res=-1;
            }
            update(a,b,res);
        }
        else{
            int x1,y1,x2,y2;
            cin>>x1>>y1>>x2>>y2;
            x1--,y1--,x2--,y2--;
            cout<<query(x1,y1,x2,y2)<<endl;
        }
    }
}

signed main(){
    fast;
    int tt=1;
    // cin>>tt;
    while(tt--){
        cases++;
        solve();
    }
    return 0;
}
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

// Se vuelve mas facil, cada dia es un poco mas facil,
// pero tienes que hacerlo cada dia, es la parte dificil, pero se vuelve mas facil.
// Crecer duele.
// La unica manera de pasar esa barrera es pasandola.
// No sirve de nada hacer sacrificios si no tienes disciplina.
// Si te caes 7 veces, levantate 8.
// LA DISCIPLINA es el puente entre tus metas y tus logros.
// Las indisciplinadas son mi debilidad.
// Take a sad song and make it better.
