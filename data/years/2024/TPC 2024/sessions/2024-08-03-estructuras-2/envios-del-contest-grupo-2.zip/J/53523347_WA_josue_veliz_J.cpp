#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

signed main() {
    ios_base::sync_with_stdio(0);
	  cin.tie(0);
    int n;
    cin >> n;
    vector<int> arr(n);
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    map<ll, int> prefix_count;
    ll prefix_sum = 0;
    ll count = 0;

    prefix_count[0] = 1;

    for (int i = 0; i < n; i++) {
        prefix_sum += arr[i];

        count += prefix_count[prefix_sum % n];

        prefix_count[prefix_sum % n]++;
    }

    cout << count << endl;
    return 0;
}