#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

struct segtree {
    int n;
    vector<long long> tree, lazy;

    void init(int size) {
        n = size;
        tree.assign(4 * n, 0);
        lazy.assign(4 * n, 0);
    }

    void push(int node, int start, int end) {
        if (lazy[node] != 0) {
            tree[node] += lazy[node]; 
            if (start != end) { 
                lazy[node * 2 + 1] += lazy[node];
                lazy[node * 2 + 2] += lazy[node];
            }
            lazy[node] = 0; 
        }
    }

    void updateRange(int node, int start, int end, int l, int r, long long value) {
        push(node, start, end);
        if (start > end || start > r || end < l) {
            return; 
        }
        if (start >= l && end <= r) {
            lazy[node] += value; 
            push(node, start, end);
            return;
        }
        int mid = (start + end) / 2;
        updateRange(node * 2 + 1, start, mid, l, r, value);
        updateRange(node * 2 + 2, mid + 1, end, l, r, value);
        tree[node] = min(tree[node * 2 + 1], tree[node * 2 + 2]);
    }

    long long queryRange(int node, int start, int end, int l, int r) {
        push(node, start, end);
        if (start > end || start > r || end < l) {
            return LLONG_MAX;
        }
        if (start >= l && end <= r) {
            return tree[node];
        }
        int mid = (start + end) / 2;
        return min(queryRange(node * 2 + 1, start, mid, l, r),
                   queryRange(node * 2 + 2, mid + 1, end, l, r));
    }

    void updateRange(int l, int r, long long value) {
        updateRange(0, 0, n - 1, l, r, value);
    }

    long long queryRange(int l, int r) {
        return queryRange(0, 0, n - 1, l, r);
    }
};

int main() {
    int n, m;
    cin >> n;

    vector<long long> arr(n);
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    segtree st;
    st.init(2 * n);

    for (int i = 0; i < n; i++) {
        st.updateRange(i, i, arr[i]);
        st.updateRange(i + n, i + n, arr[i]);
    }

    cin >> m;
    while (m--) {
        int lf, rg;
        cin >> lf >> rg;
        if (cin.peek() == ' ') {
            long long v;
            cin >> v;
            if (lf <= rg) {
                st.updateRange(lf, rg, v);
            } else {
                st.updateRange(lf, n - 1, v);
                st.updateRange(0, rg, v);
            }
        } else {
            if (lf <= rg) {
                cout << st.queryRange(lf, rg) << "\n";
            } else {
                cout << min(st.queryRange(lf, n - 1), st.queryRange(0, rg)) << "\n";
            }
        }
    }
}