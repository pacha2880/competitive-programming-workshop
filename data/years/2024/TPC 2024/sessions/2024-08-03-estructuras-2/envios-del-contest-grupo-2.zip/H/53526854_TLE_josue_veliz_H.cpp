#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

struct segtree { 
    int n;
    vl tree;

    void init(int nn) {
        tree.clear();
        n = nn;
        int size = 1;
        while (size < n) {
            size *= 2;
        }
        tree.resize(size * 2);
    }

    void update(int i, int sl, int sr, int pos, ll diff) {
        if (sl <= pos && pos <= sr) {
            if (sl == sr) {
                tree[i] += diff;
            } else {
                int mid = (sl + sr) / 2;
                update(i * 2 + 1, sl, mid, pos, diff);
                update(i * 2 + 2, mid + 1, sr, pos, diff);
                tree[i] = min(tree[i * 2 + 1], tree[i * 2 + 2]);
            }
        }
    }

    void update(int pos, ll diff) {
        update(0, 0, n - 1, pos, diff);
    }

    ll query(int i, int sl, int sr, int l, int r) {
        if (l <= sl && sr <= r) {
            return tree[i];
        } else if(sr < l || r < sl) {
            return INT64_MAX;
        } else {
            int mid = (sl + sr) / 2;
            auto a = query(i * 2 + 1, sl, mid, l, r);
            auto b = query(i * 2 + 2, mid + 1, sr, l, r);
            return min(a, b);
        }
    }

    ll query(int l, int r) {
        return query(0, 0, n - 1, l, r);
    }
};

signed main(){
  int n, m;
  cin >> n;

  segtree st;
  st.init(n);
  for (int i = 0; i < n; i++) {
    ll x;
    cin >> x;
    st.update(i, x);
  }


  cin >> m;
  while (m--) {
    int lf, rg, v;
    cin >> lf >> rg;

    if (cin.peek() == ' ') {
      cin >> v;
      if (lf <= rg) {
        for (int i = lf; i <= rg; i++) {
          st.update(i, v);
        }
      } else {
        for (int i = lf; i < n; i++) {
          st.update(i, v);
        }
        for (int i = 0; i <= rg; i++) {
          st.update(i, v);
        }
      }
    } else {
      if (lf <= rg) {
        cout << st.query(lf, rg) << "\n";
      } else {
        cout << min(st.query(lf, n - 1), st.query(0, rg)) << "\n";
      }
    }
  }
}