import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int q = sc.nextInt();
        int[] arr = new int[n + 1];
        for(int i = 1; i < n + 1; i++){
            arr[i] = sc.nextInt() + arr[i-1];
        }
        for(int i = 0; i < q; i++){
            int a = sc.nextInt();
            int b = sc.nextInt();
            int res = arr[b] - arr[a-1];
            System.out.println(res);
        }
    }
}