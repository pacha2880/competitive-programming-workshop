#include <bits/stdc++.h>
using namespace std;

#define sz(x) (int)size(x)

using ll = long long;
using vl = vector<ll>;

vl psum(const vl &a) {
	vl psum(sz(a) + 1);
	for (int i = 0; i < sz(a); ++i) psum[i + 1] = psum[i] + a[i];
	return psum;
}

int main() {
	int numComponenetes;
	int casos;
	cin>>numComponenetes;
	cin>>casos;
	vl vectorNumeros;
	vl vectorFinal;
	vl vectorResultados;
	for(int i=0;i<numComponenetes;i++){
	    int num;
	    cin>>num;
	    vectorNumeros.push_back(num);
	}
	vectorFinal=psum(vectorNumeros);
	for(int k=0;k<casos;k++){
	    int num1,num2;
	    cin>>num1>>num2;
	    ll resultado;
	    if(num2>num1){
	        resultado=vectorFinal[num2]-vectorFinal[num1-1];
	    }
	    else{
	        resultado=vectorFinal[num1]-vectorFinal[num2-1];
	    }
	    vectorResultados.push_back(resultado);
	}
	for(ll valor:vectorResultados){
	    cout<<valor<<endl;
	}
}