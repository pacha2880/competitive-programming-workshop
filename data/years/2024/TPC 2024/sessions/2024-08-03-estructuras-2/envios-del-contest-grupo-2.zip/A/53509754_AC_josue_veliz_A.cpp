#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

signed main(){
  int n, q;
  cin >> n >> q;
  vector<ll> a(n+1);
  for(int i = 1; i <= n; i++){
    cin >> a[i];
    a[i] += a[i-1];
  }
  while(q--){
    int l, r;
    cin >> l >> r;
    cout << a[r] - a[l-1] << '\n';
  }
}