#include <bits/stdc++.h>
 
#define mp              make_pair
#define pb              push_back
#define ppb             pop_back
#define all(a)          (a).begin(), (a).end()
#define sz(a)           (int)a.size()
#define f               first
#define s               second
#define forn(i, n)          for(int i = 0; i < n; i++)
 
using namespace std;
 
typedef long long ll;
 
struct Node {
    ll a;
    
    Node(ll val = LLONG_MAX) : a(val) {}
};
 
Node e() {
    Node node;
    return node;
}
 
Node op(Node a, Node b) {
    Node node;
    node.a = min(a.a, b.a);
    return node;
}
 
struct segtree { 
    vector<Node> nodes;
    ll n;
 
    void init(ll n) {
        auto a = vector<Node>(n, e());
        init(a);
    }
 
    void init(vector<Node>& initial) {
        nodes.clear();
        n = initial.size();
        int size = 1;
        while (size < n) {
            size *= 2;
        }
        nodes.resize(size * 2);
        build(0, 0, n-1, initial);
    }
 
    void build(int i, int sl, int sr, vector<Node>& initial) {
        if (sl == sr) {
            nodes[i] = initial[sl];
        } else {
            ll mid = (sl + sr) >> 1;
            build(i*2+1, sl, mid, initial);
            build(i*2+2, mid+1,sr,initial);
            nodes[i] = op(nodes[i*2+1], nodes[i*2+2]);
        }
    }
 
    void update(int i, int sl, int sr, int pos, Node node) {
        if (sl <= pos && pos <= sr) {
            if (sl == sr) {
                nodes[i] = node;
            } else {
                int mid = (sl + sr) >> 1;
                update(i * 2 + 1, sl, mid, pos, node);
                update(i * 2 + 2, mid + 1, sr, pos, node);
                nodes[i] = op(nodes[i*2+1], nodes[i*2+2]);
            }
        }
    }
 
    void update(int pos, Node node) {
        update(0, 0, n - 1, pos, node);
    }
 
    Node query(int i, int sl, int sr, int l, int r) {
        if (l <= sl && sr <= r) {
            return nodes[i];
        } else if(sr < l || r < sl) {
            return e();
        } else {
            int mid = (sl + sr) / 2;
            auto a = query(i * 2 + 1, sl, mid, l, r);
            auto b = query(i * 2 + 2, mid + 1, sr, l, r);
            return op(a, b);
        }
    }
 
    Node query(int l, int r) {
        return query(0, 0, n - 1, l, r);
    }
 
    Node get(int i) {
        return query(i, i);
    }
};
 
 
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    ll n, q;
    ll x, x1, y1;
 
    cin >> n >> q;
    segtree bit;
    bit.init(n);
    forn(i, n) {
        cin >> x;
        bit.update(i, Node(x));
    }
 
    forn(i, q) {
        cin >> x >> x1 >> y1;
        if (x == 1) {
            bit.update(x1 - 1, Node(y1));
        } else {
            auto minv = bit.query(x1 - 1, y1 - 1);
            cout << minv.a << '\n';
        }
    }
    
    return 0;
}