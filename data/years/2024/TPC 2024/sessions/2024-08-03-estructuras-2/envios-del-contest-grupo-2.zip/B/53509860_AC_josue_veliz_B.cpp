#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

signed main(){
  int n, q;
  cin >> n >> q;
  vector<vector<int>> matrix(n, vector<int>(n));
  vector<vector<int>> prefix(n+1, vector<int>(n+1));
  for(int i = 0; i < n; i++){
    string s;
    cin >> s;
    for(int j = 0; j < n; j++){
      matrix[i][j] = s[j] == '*';
    }
  }
  for(int i = 1; i <= n; i++){
    for(int j = 1; j <= n; j++){
      prefix[i][j] = prefix[i-1][j] + prefix[i][j-1] - prefix[i-1][j-1] + matrix[i-1][j-1];
    }
  }
  while(q--){
    int x1, y1, x2, y2;
    cin >> x1 >> y1 >> x2 >> y2;
    cout << prefix[x2][y2] - prefix[x1-1][y2] - prefix[x2][y1-1] + prefix[x1-1][y1-1] << '\n';
  }
}