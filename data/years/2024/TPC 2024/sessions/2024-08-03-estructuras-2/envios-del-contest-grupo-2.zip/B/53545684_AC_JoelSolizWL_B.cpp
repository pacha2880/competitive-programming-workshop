#include <bits/stdc++.h>

#define mp              make_pair
#define pb              push_back
#define ppb             pop_back
#define all(a)          (a).begin(), (a).end()
#define sz(a)           (int)a.size()
#define f               first
#define s               second
#define forn(i, n)          for(int i = 0; i < n; i++)

using namespace std;

typedef long long ll;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n, q, x1, y1, x2, y2;

    cin >> n >> q;
    vector<string> s(n);
    forn(i, n) cin >> s[i];

    vector<vector<ll>> pf(n + 1, vector<ll>(n + 1));    
    forn(i, n) {
        forn(j, n) {
            ll value = s[i][j] == '*';
            pf[i + 1][j + 1] = value + pf[i][j + 1] + pf[i + 1][j] - pf[i][j];
        }
    }
    
    forn(i, q) {
        cin >> x1 >> y1 >> x2 >> y2;
        x1--, y1--, x2--, y2--;
        ll trees = pf[x2 + 1][y2 + 1] - pf[x1][y2 + 1] - pf[x2 + 1][y1] + pf[x1][y1];
        cout << trees << '\n';
    }
    
    return 0;
}