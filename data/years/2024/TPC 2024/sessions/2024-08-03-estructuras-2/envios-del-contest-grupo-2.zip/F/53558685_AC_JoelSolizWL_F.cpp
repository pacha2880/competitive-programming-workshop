#include <bits/stdc++.h>
 
#define mp              make_pair
#define pb              push_back
#define ppb             pop_back
#define all(a)          (a).begin(), (a).end()
#define sz(a)           (int)a.size()
#define f               first
#define s               second
#define forn(i, n)          for(int i = 0; i < n; i++)
 
using namespace std;
 
typedef long long ll;
typedef vector<ll> vl;
 
struct lazytree {
    int n;
    vl sum;
    vl lazySum;

    void init(int nn) {
        sum.clear();
        n = nn;
        int size = 1;
        while (size < n) {
            size *= 2;
        }
        sum.resize(size * 2);
        lazySum.resize(size * 2);
    }

    void update(int i, int sl, int sr, int l, int r, ll diff) {
        if (lazySum[i]) {
            sum[i] += (sr - sl + 1) * lazySum[i];
            if (sl != sr) {
                lazySum[i * 2 + 1] += lazySum[i];
                lazySum[i * 2 + 2] += lazySum[i];
            }
            lazySum[i] = 0;
        }
        if (l <= sl && sr <= r) {
            sum[i] += (sr - sl + 1) * diff;
            if (sl != sr) {
                lazySum[i * 2 + 1] += diff;
                lazySum[i * 2 + 2] += diff;
            }
        } else if (sr < l || r < sl) {
        } else {
            int mid = (sl + sr) >> 1;
            update(i * 2 + 1, sl, mid, l, r, diff);
            update(i * 2 + 2, mid + 1, sr, l, r, diff);
            sum[i] = sum[i * 2 + 1] + sum[i * 2 + 2];
        }
    }

    void update(int l, int r, ll diff) {
        assert(l <= r);
        assert(r < n);
        update(0, 0, n - 1, l, r, diff);
    }

    ll query(int i, int sl, int sr, int l, int r) {
        if (lazySum[i]) {
            sum[i] += lazySum[i] * (sr - sl + 1);
            if (sl != sr) {
                lazySum[i * 2 + 1] += lazySum[i];
                lazySum[i * 2 + 2] += lazySum[i];
            }
            lazySum[i] = 0;
        }
        if (l <= sl && sr <= r) {
            return sum[i];
        } else if (sr < l || r < sl) {
            return 0;
        } else {
            int mid = (sl + sr) >> 1;
            return query(i * 2 + 1, sl, mid, l, r) + query(i * 2 + 2, mid + 1, sr, l, r);
        }
    }

    ll query(int l, int r) {
        assert(l <= r);
        assert(r < n);
        return query(0, 0, n - 1, l, r);
    }
};

 
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    ll n, q;
    ll x, v, y, z;
 
    cin >> n >> q;
    lazytree bit;
    bit.init(n);
    forn(i, n) {
        cin >> x;
        bit.update(i, i, x);
    }
 
    forn(i, q) {
        cin >> x;
        if (x == 1) {
            cin >> v >> y >> z;
            bit.update(v - 1, y - 1, z);
        } else {
            cin >> v;
            auto val = bit.query(v - 1, v - 1);
            cout << val << '\n';
        }
    }
    
    return 0;
}