#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

signed main() {
    int n;
    ll x;
    cin >> n >> x;
    vector<ll> arr(n);
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    unordered_map<ll, int> prefix_count;
    ll prefix_sum = 0;
    int count = 0;

    prefix_count[0] = 1;

    for (int i = 0; i < n; i++) {
        prefix_sum += arr[i];

        if (prefix_count.find(prefix_sum - x) != prefix_count.end()) {
            count += prefix_count[prefix_sum - x];
        }

        prefix_count[prefix_sum]++;
    }

    cout << count << endl;
    return 0;
}