#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

signed main(){
  int n, q;
  cin >> n >> q;
  vector<ll> prefiXor(n+1);
  for(int i = 1; i <= n; i++){
    int x;
    cin >> x;
    prefiXor[i] = prefiXor[i-1] ^ x;
  }
  while(q--){
    int l, r;
    cin >> l >> r;
    cout << (prefiXor[r] ^ prefiXor[l-1]) << '\n';
  }
}