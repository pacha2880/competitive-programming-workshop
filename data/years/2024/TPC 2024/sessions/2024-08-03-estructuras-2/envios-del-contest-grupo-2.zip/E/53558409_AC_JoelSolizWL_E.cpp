#include <bits/stdc++.h>

#define mp              make_pair
#define pb              push_back
#define ppb             pop_back
#define all(a)          (a).begin(), (a).end()
#define sz(a)           (int)a.size()
#define f               first
#define s               second
#define forn(i, n)          for(int i = 0; i < n; i++)

using namespace std;

typedef long long ll;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n, q, a, b;
    cin >> n >> q;
    vector<ll> nums(n), pf(n + 1, 0);
    forn(i, n) cin >> nums[i], pf[i + 1] = pf[i] ^ nums[i];
    
    forn(i, q) {
        cin >> a >> b;
        cout << (pf[b] ^ pf[a - 1]) << '\n';
    }
    
    return 0;
}