#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define F first
#define S second
#define all(x) (x).begin(), (x).end()

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using vb = vector<bool>;

struct BIT2D{
  vector<vector<int>> bit;
  int n, m;
  BIT2D(int n, int m): n(n), m(m){
    bit.assign(n+1, vector<int>(m+1));
  }
  void add(int x, int y, int val){
    for(int i = x; i <= n; i += i & -i){
      for(int j = y; j <= m; j += j & -j){
        bit[i][j] += val;
      }
    }
  }
  int sum(int x, int y){
    int res = 0;
    for(int i = x; i > 0; i -= i & -i){
      for(int j = y; j > 0; j -= j & -j){
        res += bit[i][j];
      }
    }
    return res;
  }
  int sum(int x1, int y1, int x2, int y2){
    return sum(x2, y2) - sum(x1-1, y2) - sum(x2, y1-1) + sum(x1-1, y1-1);
  }
};

signed main(){
  int n, q;
  cin >> n >> q;
  vector<string> grid(n);
  for(int i = 0; i < n; i++){
    cin >> grid[i];
  }
  BIT2D bit(n, n);
  for(int i = 0; i < n; i++){
    for(int j = 0; j < n; j++){
      bit.add(i+1, j+1, grid[i][j] == '*');
    }
  }
  while(q--){
    int t;
    cin >> t;
    if(t == 1){
      int x, y;
      cin >> x >> y;
      bit.add(x, y, grid[x-1][y-1] == '*'? -1 : 1);
      grid[x-1][y-1] = grid[x-1][y-1] == '*'? '.' : '*';
    }else{
      int x1, y1, x2, y2;
      cin >> x1 >> y1 >> x2 >> y2;
      cout << bit.sum(x1, y1, x2, y2) << '\n';
    }
  }
}