#include <bits/stdc++.h>

#define mp              make_pair
#define pb              push_back
#define ppb             pop_back
#define all(a)          (a).begin(), (a).end()
#define sz(a)           (int)a.size()
#define f               first
#define s               second
#define forn(i, n)          for(int i = 0; i < n; i++)

using namespace std;

typedef long long ll;

struct BIT2D {
    vector<vector<ll>> bit;
    ll n, m;
 
    BIT2D(ll n, ll m) : bit(n + 1, vector<ll>(m + 1)), n(n), m(m) {}
 
    ll lsb(ll i) {
        return i & -i;
    }
 
    void add(int row, int col, ll x) {
        for (int i = row;i<=n;i+=lsb(i)) {
            for (int j = col;j<=m;j+=lsb(j)) {
                bit[i][j] += x;
            }
        }
    }
 
    ll sum(int row, int col) {
        ll res = 0;
        for (int i = row;i>0;i-=lsb(i)) {
            for (int j = col;j>0;j-=lsb(j)) {
                res += bit[i][j];
            }
        }
        return res;
    }
 
    ll sum(int x1, int y1, int x2, int y2) {
        return sum(x2,y2) - sum(x1-1,y2) - sum(x2,y1-1) + sum(x1-1,y1-1);
    }
 
    void set(int x, int y, ll val) {
        add(x,y,val-sum(x,y,x,y));
    }
};


int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int n, q, x, x1, y1, x2, y2;

    cin >> n >> q;
    vector<string> s(n);
    forn(i, n) cin >> s[i];

    BIT2D bit2d(n, n); 
    forn(i, n) {
        forn(j, n) {
            ll value = s[i][j] == '*';
            bit2d.set(i + 1, j + 1, value);
        }
    }
    
    forn(i, q) {
        cin >> x;
        if (x == 1) {
            cin >> x1 >> y1;
            ll value = s[x1-1][y1-1] != '*';
            s[x1-1][y1-1] = s[x1-1][y1-1] == '*' ? '.' : '*';
            bit2d.set(x1, y1, value);
        } else {
            cin >> x1 >> y1 >> x2 >> y2;
            //x1--, y1--, x2--, y2--;
            ll trees = bit2d.sum(x1, y1, x2, y2);
            cout << trees << '\n';
        }
    }
    
    return 0;
}