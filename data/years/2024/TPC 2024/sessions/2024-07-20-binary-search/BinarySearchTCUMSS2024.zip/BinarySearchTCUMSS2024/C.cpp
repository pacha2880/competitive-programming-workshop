#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;


struct node{
    ll who, vala, valb;
};
 
const ll N = 2e5+10;
ll n; ll cont = 0; 
vector<node> adj[N];
bool vis[N];
vector<ll> ans(N), a(N), b(N);

void dfs(int s, int cont){
    for(auto u: adj[s]){
        ll who = u.who, vala = u.vala, valb = u.valb;
        if(vis[who]) continue;
        vis[who] = 1;
        if(cont==0){
            a[cont] = vala;
            b[cont] = valb;
        }else{
            a[cont] = a[cont-1] + vala;
            b[cont] = b[cont-1] + valb;
        }
        ll lo = 0, hi = cont, med = 0, res = -1;
        while(lo<=hi){
            med = (lo+hi)/2;
            if(a[cont] >= b[med]){
                lo = med+1;
                res = med;
            }else hi = med-1;
        }
        ans[who] = res+1;
        dfs(who, cont+1);
    }
}

int main(){
    fast_cin();
    //freopen("input.in", "r", stdin);
    //freopen("output.out", "w", stdout);
    int t; cin>>t;
    while(t--){
        int n; cin>>n;
        fore(i,0,n) adj[i].clear();
        fore(i,0,n) ans[i] = 0;
        fore(i,1,n){
            ll x,y,z; cin>>x>>y>>z;
            x--;
            adj[i].pb({x,y,z});
            adj[x].pb({i,y,z});
        }
        forn(i,n) vis[i] = 0;
        vis[0] = 1;
        dfs(0,0);
        fore(i,1,n) cout<<ans[i]<<" ";
        cout<<endl;
    }
    return 0;
}