#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 
const ll N = 1e5+10;
ll n, duracion;
vector<double> velocidad(N), distancia(N);

double f(double time){
    double posmi = INF, posma = -INF;
    for(int i = 0; i < n; i++){
        posmi = min(posmi, distancia[i] + time*velocidad[i]);
        posma = max(posma, distancia[i] + time*velocidad[i]);
    }
    return posma - posmi;
}

int main(){
    fast_cin();
    cin>>n>>duracion;
    forn(i,n) cin>>velocidad[i]>>distancia[i];
    double l = 0, r = duracion, med = 0, res = -1;
    for(int i = 0; i < 100; i++){
        double m1 = l + (r - l) / 3;
        double m2 = r - (r - l) / 3;
        //esto con m1 
        double resm1 = f(m1), resm2 = f(m2);
        if(resm1 > resm2) l = m1;
        else r = m2;
    } 
    cout<<fixed<<setprecision(6)<<f(l)<<endl;
    return 0;
}


