#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 

int main(){
    fast_cin();
    ll n,m; cin>>n>>m;
    vector<ll> a(n), b(m);
    forn(i,n) cin>>a[i];
    forn(i,m) cin>>b[i];
    sort(all(a));
    forn(i,m){
        ll lo = 0, hi = n-1, med = 0, res = -1;
        while(lo<=hi){
            med = (lo+hi)/2;
            if(a[med]<=b[i]){
                res = med;
                lo = med+1;
            }else hi = med-1;
        }
        cout<<res+1<<" ";
    }
    return 0;
}


