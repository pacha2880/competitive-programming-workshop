#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;

const ll N = 2e5+10;
vector<double> vec(N), copia(N);
ll n;

double f(double numResto){
    copia = vec;
    double ans = 0;
    for(int i = 0; i < n; i++) copia[i] -= numResto;
    double ma = 0, res = 0, sumCurr = 0;
    for(int i = 0; i < n; i++){
        sumCurr += copia[i];
        if(sumCurr <= 0) sumCurr = 0;
        else ma = max(sumCurr, ma);
    }
    for(int i = 0; i < n; i++) copia[i] *= -1;
    sumCurr = 0;
    for(int i = 0; i < n; i++){
        sumCurr += copia[i];
        if(sumCurr <= 0) sumCurr = 0;
        else ma = max(sumCurr, ma);
    }
    return ma;
}

//haces el ternary sobre el numero que vas a restar
double ternary_search(double l, double r, int No = 300){
     for(int i = 0; i < No; i++){
        double m1 = l + (r - l) / 3;
        double m2 = r - (r - l) / 3;
        if (f(m1) > f(m2))
            l = m1;
        else
            r = m2;
    }
    return f(l);  
}

int main(){
    fast_cin();
    cin>>n;
    double ma = 0;
    forn(i,n) cin>>vec[i], ma = max(ma, abs(vec[i]));
    double pri = -ma;
    double ans = ternary_search(pri, ma);
    cout<<fixed<<setprecision(8)<<ans<<endl;
    return 0;
}

 