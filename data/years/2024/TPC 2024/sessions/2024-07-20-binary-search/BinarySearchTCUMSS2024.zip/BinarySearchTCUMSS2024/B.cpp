#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 

int main(){
    fast_cin();
    ll n,k; cin>>n>>k;
    string s; cin>>s;
    vector<ll> pref(n);
    pref[0] = (s[0] == '0');
    fore(i,1,n) pref[i] = pref[i-1] + (s[i] == '0');
    ll ans = INF;
    forn(i,n){
        ll personaPos = i;
        if(s[i] == '1') continue;
        ll lo = 0, hi = n-1, med = 0, res = -1;
        while(lo<=hi){
            med = (lo+hi)/2;
            ll posMasIzq = max(0ll, i-med), posMasDer = min(n-1, i+med);            
            ll cuantoIzq = 0, cuantoDer = 0;
            if(i-1 >= 0) cuantoIzq = pref[i-1]-pref[posMasIzq]+(s[posMasIzq] == '0');
            if(i+1 < n) cuantoDer = pref[posMasDer]-pref[i+1]+(s[i+1] == '0');
            if(cuantoIzq+cuantoDer >= k){
                res = med;
                hi = med-1;
            }else lo = med+1;
        }
        if(res != -1) ans = min(ans, res);
    }
    cout<<ans<<endl;
    return 0;
}
