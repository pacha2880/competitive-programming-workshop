#include <bits/stdc++.h>  
 
#define ll                    long long
#define ld                    long double
#define mp                    make_pair
#define pb                    push_back
#define fi                    first
#define se                    second
#define INF                   2e18
#define all(x)                (x).begin(), (x).end()
#define sz(x)                 ((int)(x).size())
#define forn(i,n)             for(int i = 0; i < n; i++)
#define fore(i,b,e)           for(int i = b; i < e; i++)
#define forg(i,b,e,m)         for(int i = b; i < e; i+=m)
#define rforn(i,n)            for(int i = n; i >= 0; i--)
#define rfore(i,b,e)          for(int i = b; i >= e; i--)
#define rforg(i,b,e,m)        for(int i = s; i >= e; i-=m)
#define endl                  "\n"
#define MOD                   1000000007
#define fast_cin()            ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
 

int main(){
    fast_cin();
    string s; cin>>s;
    ll n = sz(s);
    ll cantB, cantS, cantC; cin>>cantB>>cantS>>cantC;
    ll pB, pS, pC; cin>>pB>>pS>>pC; //precio 
    ll dinero; cin>>dinero;  //El dinero que tengo
    ll lo = 0, hi = 1e15, med = 0, res = -1;
    //para hacer una hamburguesa cuantos ingredientes necesito
    ll cuantoB = 0, cuantoS = 0, cuantoC = 0;
    forn(i,n){
        if(s[i]=='B') cuantoB++;
        if(s[i]=='S') cuantoS++;
        if(s[i]=='C') cuantoC++;
    }
    while(lo<=hi){
        med = (lo+hi)/2;
        ll numH = med;
        ll needB = cuantoB*numH, needS = cuantoS*numH, needC = cuantoC*numH;
        needB = max(0LL, needB-cantB);
        needS = max(0LL, needS-cantS);
        needC = max(0LL, needC-cantC);
        ll costo = needB*pB + needS*pS + needC*pC;
        if(costo<=dinero){
            res = med;
            lo = med+1;
        }else hi = med-1;
    }
    cout<<res<<endl;
    return 0;
}


